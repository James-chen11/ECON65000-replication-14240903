"""Single entry point for the UK inflation dissertation replication package."""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parent
PYTHON = Path(sys.executable)
LOG_DIR = ROOT / "outputs" / "logs"

PRIMARY_BASELINE = ROOT / "outputs" / "full_with_random_forest" / "predictions.csv"
PRIMARY_BBIM_DIR = (
    ROOT
    / "outputs"
    / "bbim_ukmd"
    / "paper_200801_r100_e10_ilag0_plags3_mono"
)
PRIMARY_BBIM = PRIMARY_BBIM_DIR / "bbim_predictions_all.csv"
PRIMARY_NN_DIR = (
    ROOT
    / "outputs"
    / "neural_network_ukmd"
    / "paper_200801_cv5_cvtrain72_v2_ilag0_plags4_s61351-61352-61353-61354-61355"
)
PRIMARY_NN = PRIMARY_NN_DIR / "nn_predictions_all.csv"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--mode",
        choices=("reproduce", "smoke", "full"),
        default="reproduce",
        help="reproduce: rebuild tables from frozen forecasts; smoke: small model check; full: refit everything",
    )
    parser.add_argument(
        "--skip-robustness",
        action="store_true",
        help="Only affects full mode. Primary models are still re-estimated.",
    )
    parser.add_argument(
        "--skip-interpretability",
        action="store_true",
        help="Skip BBIM contribution and Random-Forest TreeSHAP regeneration.",
    )
    return parser.parse_args()


def require_files(paths: list[Path]) -> None:
    missing = [str(path.relative_to(ROOT)) for path in paths if not path.exists()]
    if missing:
        raise FileNotFoundError("Missing required replication inputs: " + ", ".join(missing))


def run_step(label: str, command: list[str]) -> None:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    log_path = LOG_DIR / f"{label}.log"
    print(f"\n[{label}]", flush=True)
    print(subprocess.list2cmdline(command), flush=True)
    env = os.environ.copy()
    env["PYTHONUTF8"] = "1"
    with log_path.open("w", encoding="utf-8") as log:
        process = subprocess.Popen(
            command,
            cwd=ROOT,
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        assert process.stdout is not None
        for line in process.stdout:
            print(line, end="")
            log.write(line)
        return_code = process.wait()
    if return_code:
        raise subprocess.CalledProcessError(return_code, command)


def python_command(relative_script: str, *arguments: str) -> list[str]:
    return [str(PYTHON), str(ROOT / relative_script), *arguments]


def run_tests() -> None:
    run_step(
        "00_data_contract_tests",
        [str(PYTHON), "-m", "unittest", "discover", "-s", "tests", "-v"],
    )


def reproduce(skip_interpretability: bool) -> Path:
    require_files(
        [
            ROOT / "data" / "UKMD_March_2026" / "raw_uk_md.csv",
            ROOT / "data" / "UKMD_March_2026" / "balanced_uk_md.csv",
            PRIMARY_BASELINE,
            PRIMARY_BBIM,
            PRIMARY_NN,
        ]
    )
    output_root = ROOT / "outputs" / "reproduced"
    master_dir = output_root / "final_master"
    interpretability_dir = output_root / "interpretability"
    figure_dir = ROOT / "artifacts" / "reproduced_figures"

    run_step(
        "10_consolidate_frozen_predictions",
        python_command(
            "analysis/05_consolidate_final_results.py",
            "--baseline", str(PRIMARY_BASELINE),
            "--bbim", str(PRIMARY_BBIM),
            "--neural-network", str(PRIMARY_NN),
            "--output-dir", str(master_dir),
        ),
    )
    run_step(
        "11_summarise_frozen_robustness",
        python_command(
            "analysis/06_summarise_robustness.py",
            "--robustness-root", str(ROOT / "outputs" / "robustness"),
            "--output-dir", str(output_root / "robustness_summary"),
        ),
    )
    if not skip_interpretability:
        run_step(
            "12_regenerate_interpretability",
            python_command(
                "analysis/07_interpretability.py",
                "--mode", "both",
                "--bbim-dir", str(PRIMARY_BBIM_DIR),
                "--master-dir", str(master_dir),
                "--data-dir", str(ROOT / "data" / "UKMD_March_2026"),
                "--output-dir", str(interpretability_dir),
            ),
        )
    else:
        interpretability_dir = ROOT / "outputs" / "interpretability"
    run_step(
        "13_regenerate_figures",
        python_command(
            "analysis/08_generate_final_figures.py",
            "--master-dir", str(master_dir),
            "--interpretability-dir", str(interpretability_dir),
            "--output-dir", str(figure_dir),
        ),
    )
    run_step(
        "14_verify_against_reported_results",
        python_command(
            "tools/verify_results.py",
            "--candidate", str(master_dir),
            "--reference", str(ROOT / "reference_results"),
        ),
    )
    return output_root


def smoke() -> Path:
    output_root = ROOT / "outputs" / "smoke_check"
    baseline_dir = output_root / "baseline"
    bbim_dir = output_root / "bbim"
    nn_dir = output_root / "neural_network"
    run_step(
        "20_smoke_baseline",
        python_command(
            "src/forecast_pipeline.py",
            "--smoke",
            "--output-dir", str(baseline_dir),
        ),
    )
    benchmark = baseline_dir / "predictions.csv"
    run_step(
        "21_smoke_bbim",
        python_command(
            "analysis/03_bbim_ukmd_paper_style.py",
            "--mode", "smoke",
            "--benchmark-predictions", str(benchmark),
            "--output-dir", str(bbim_dir),
        ),
    )
    run_step(
        "22_smoke_neural_network",
        python_command(
            "analysis/04_neural_network_ukmd.py",
            "--mode", "smoke",
            "--benchmark-predictions", str(benchmark),
            "--output-dir", str(nn_dir),
        ),
    )
    require_files(
        [
            benchmark,
            bbim_dir / "bbim_predictions_all.csv",
            nn_dir / "nn_predictions_all.csv",
        ]
    )
    print("Smoke check passed: baseline, BBIM and neural-network outputs were created.")
    return output_root


def full(skip_robustness: bool, skip_interpretability: bool) -> Path:
    output_root = ROOT / "outputs" / "full_reproduction"
    baseline_dir = output_root / "baseline"
    bbim_dir = output_root / "bbim"
    nn_dir = output_root / "neural_network"
    master_dir = output_root / "final_master"
    interpretability_dir = output_root / "interpretability"
    figure_dir = ROOT / "artifacts" / "full_reproduction_figures"

    run_step(
        "30_full_baseline_and_random_forest",
        python_command(
            "src/forecast_pipeline.py",
            "--horizons", "1", "3", "6", "12",
            "--output-dir", str(baseline_dir),
        ),
    )
    run_step(
        "31_full_bbim",
        python_command(
            "analysis/03_bbim_ukmd_paper_style.py",
            "--mode", "paper",
            "--horizons", "1", "3", "6", "12",
            "--benchmark-predictions", str(baseline_dir / "predictions.csv"),
            "--output-dir", str(bbim_dir),
        ),
    )
    run_step(
        "32_full_neural_network",
        python_command(
            "analysis/04_neural_network_ukmd.py",
            "--mode", "paper",
            "--horizons", "1", "3", "6", "12",
            "--benchmark-predictions", str(baseline_dir / "predictions.csv"),
            "--output-dir", str(nn_dir),
        ),
    )
    run_step(
        "33_full_consolidation",
        python_command(
            "analysis/05_consolidate_final_results.py",
            "--baseline", str(baseline_dir / "predictions.csv"),
            "--bbim", str(bbim_dir / "bbim_predictions_all.csv"),
            "--neural-network", str(nn_dir / "nn_predictions_all.csv"),
            "--output-dir", str(master_dir),
        ),
    )
    if not skip_robustness:
        robustness_jobs = [
            "R1_ILAG1_FULL",
            "R2_CORE_H1", "R2_CORE_H3", "R2_CORE_H6", "R2_CORE_H12",
            "R3_ROLLING_H1", "R3_ROLLING_H3", "R3_ROLLING_H6", "R3_ROLLING_H12",
            "R4_ARLAGS_2", "R4_ARLAGS_6",
            "R5_RF_SEED_61352_H6", "R5_RF_SEED_61353_H6",
            "R6_BBIM_ILAG1_H6", "R7_BBIM_NOMONO_H6", "R8_NN_ILAG1_H12",
        ]
        run_step(
            "34_full_robustness",
            python_command("analysis/06_run_robustness.py", "--run", *robustness_jobs),
        )
        run_step(
            "35_full_robustness_summary",
            python_command(
                "analysis/06_summarise_robustness.py",
                "--output-dir", str(output_root / "robustness_summary"),
            ),
        )
    if not skip_interpretability:
        run_step(
            "36_full_interpretability",
            python_command(
                "analysis/07_interpretability.py",
                "--mode", "both",
                "--bbim-dir", str(bbim_dir),
                "--master-dir", str(master_dir),
                "--data-dir", str(ROOT / "data" / "UKMD_March_2026"),
                "--output-dir", str(interpretability_dir),
            ),
        )
    run_step(
        "37_full_figures",
        python_command(
            "analysis/08_generate_final_figures.py",
            "--master-dir", str(master_dir),
            "--interpretability-dir", str(
                interpretability_dir if interpretability_dir.exists()
                else ROOT / "outputs" / "interpretability"
            ),
            "--output-dir", str(figure_dir),
        ),
    )
    run_step(
        "38_compare_full_with_reported_results",
        python_command(
            "tools/verify_results.py",
            "--candidate", str(master_dir),
            "--reference", str(ROOT / "reference_results"),
        ),
    )
    return output_root


def write_run_record(mode: str, output_root: Path) -> None:
    record = {
        "mode": mode,
        "completed_utc": datetime.now(timezone.utc).isoformat(),
        "python": sys.version,
        "executable": str(PYTHON),
        "output_root": str(output_root),
    }
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    (LOG_DIR / "last_successful_run.json").write_text(
        json.dumps(record, indent=2), encoding="utf-8"
    )


def main() -> None:
    args = parse_args()
    print(f"Replication root: {ROOT}")
    print(f"Python: {PYTHON}")
    run_tests()
    if args.mode == "reproduce":
        output_root = reproduce(args.skip_interpretability)
    elif args.mode == "smoke":
        output_root = smoke()
    else:
        output_root = full(args.skip_robustness, args.skip_interpretability)
    write_run_record(args.mode, output_root)
    print(f"\nReplication mode '{args.mode}' completed successfully.")
    print(f"Outputs: {output_root}")


if __name__ == "__main__":
    main()
