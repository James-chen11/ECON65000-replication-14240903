param(
    [ValidateSet("reproduce", "smoke", "full")]
    [string]$Mode = "reproduce",
    [switch]$SkipRobustness,
    [switch]$SkipInterpretability,
    [switch]$SkipInstall
)

$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$VenvPython = Join-Path $ProjectRoot ".venv\Scripts\python.exe"
$Requirements = Join-Path $ProjectRoot "requirements.txt"

if (-not (Test-Path -LiteralPath $VenvPython)) {
    $PyLauncher = Get-Command py -ErrorAction SilentlyContinue
    if ($null -ne $PyLauncher) {
        & py -3 -m venv (Join-Path $ProjectRoot ".venv")
    }
    else {
        $SystemPython = Get-Command python -ErrorAction Stop
        & $SystemPython.Source -m venv (Join-Path $ProjectRoot ".venv")
    }
}

if (-not $SkipInstall) {
    & $VenvPython -m pip install --upgrade pip
    & $VenvPython -m pip install -r $Requirements
}

$Arguments = @((Join-Path $ProjectRoot "run_all.py"), "--mode", $Mode)
if ($SkipRobustness) { $Arguments += "--skip-robustness" }
if ($SkipInterpretability) { $Arguments += "--skip-interpretability" }

& $VenvPython @Arguments
exit $LASTEXITCODE
