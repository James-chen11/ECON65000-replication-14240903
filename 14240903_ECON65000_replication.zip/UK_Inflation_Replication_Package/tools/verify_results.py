"""Compare regenerated dissertation tables with the frozen reported results."""

from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd


FILES = (
    "all_model_predictions.csv",
    "all_model_metrics.csv",
    "main_results_with_dm.csv",
    "all_model_regime_metrics.csv",
    "all_model_dm_vs_ar.csv",
    "winner_vs_runner_up_dm.csv",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate", type=Path, required=True)
    parser.add_argument("--reference", type=Path, required=True)
    return parser.parse_args()


def canonical(frame: pd.DataFrame) -> pd.DataFrame:
    sort_columns = [
        column
        for column in frame.columns
        if not pd.api.types.is_float_dtype(frame[column])
    ]
    if sort_columns:
        frame = frame.sort_values(sort_columns, kind="stable", na_position="last")
    return frame.reset_index(drop=True)


def main() -> None:
    args = parse_args()
    for filename in FILES:
        candidate_path = args.candidate / filename
        reference_path = args.reference / filename
        if not candidate_path.exists() or not reference_path.exists():
            raise FileNotFoundError(f"Missing comparison file: {filename}")
        candidate = canonical(pd.read_csv(candidate_path))
        reference = canonical(pd.read_csv(reference_path))
        pd.testing.assert_frame_equal(
            candidate,
            reference,
            check_dtype=False,
            check_exact=False,
            rtol=1e-10,
            atol=1e-10,
        )
        print(f"PASS {filename}: {len(candidate):,} rows")
    print("All regenerated result tables match the reported reference results.")


if __name__ == "__main__":
    main()
