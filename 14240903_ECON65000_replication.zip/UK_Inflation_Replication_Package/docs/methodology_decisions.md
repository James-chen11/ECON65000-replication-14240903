# Methodology decisions after the presentation

## 1. Empirical question

The main question is whether data-rich machine-learning methods improve UK CPI
inflation forecasts relative to transparent time-series benchmarks. “Stable”
means stable forecast performance across economic regimes, not long-run
parameter stability.

## 2. Sample facts that affect the design

- Raw headline CPI is available before 1998, but the fully balanced UK-MD panel
  runs from January 1998 to February 2026.
- Therefore, a forecast evaluation beginning in January 2008 has about ten years
  of initial panel data, not twenty years.
- A genuine twenty-year initial training window with the full panel would delay
  the first forecast origin until 2018. This should be a robustness design or a
  supervisor choice, not an undocumented mixture of the two samples.
- The current balanced panel contains 111 predictors. Four lags plus two
  inflation measures produce 452 candidate panel features.

## 3. Forecast target

For each horizon `h`, the direct forecast target is annualised average inflation:

`pi[t+h,h] = (1200 / h) * log(CPI[t+h] / CPI[t])`.

At `h=12`, this is the familiar twelve-month inflation rate. At shorter horizons,
it is an annualised average over the next `h` months. The raw CPI index is named
`CPI_ALL_INDEX` in the code so it cannot be confused with UK-MD's transformed
`CPI_ALL` predictor.

## 4. Information set and leakage rule

The code uses direct multi-step forecasts. For a forecast made at origin `t`, an
`h`-month target that starts at `s` is only available for training if `s+h <= t`.
Consequently, the latest training target starts at `t-h`. Hyperparameter tuning
uses time-series splits with an additional horizon-sized gap.

The current exercise is pseudo out-of-sample and uses revised data. It is not a
real-time vintage-data exercise. A stricter information-release design that lags
all monthly predictors by at least one month remains a required robustness check.

## 5. Why transform predictors

Stationarity is not a mechanical requirement for every machine-learning model.
The reason for using the UK-MD transformations is empirical comparability and
forecast stability: log differences or differences reduce stochastic trends,
limit spurious linear relationships, and make PCA factors and regularised linear
models more stable. Rates and bounded variables should not be differenced only
for appearance; the provider's transformation codes must be audited variable by
variable. The forecast target is already a log change rather than the CPI level.

## 6. Model staging

1. Naive current-inflation forecast and direct AR benchmark.
2. Factor-augmented AR, Ridge, and LASSO.
3. Random Forest and gradient boosting after the full linear pipeline is stable.
4. Neural networks and the blockwise boosted inflation model only as extensions.

The main dissertation comparison uses horizons 1, 3, 6, and 12. Horizon 24 is
kept separate as a later robustness extension so that it does not dilute the
main comparison with Joseph et al. and the broader inflation-forecasting
literature.

## 7. Evaluation

- RMSE and MAE overall and relative to the direct AR benchmark.
- Results by target-date regime: pre-Covid, Covid, high inflation, and
  disinflation.
- Harvey-adjusted Diebold-Mariano-style tests use horizon-appropriate HAC
  variance for each candidate model against AR.
- Horizon-specific results are primary. An equal-weighted average of relative
  RMSE across 1/3/6/12 months is reported only as a secondary model ranking.
- A separate 3/6/12-month table is produced for comparison with Joseph et al.
- Regime sample sizes are small, so regime rankings are descriptive unless
  uncertainty is reported.

## 8. First pipeline evidence

The completed linear run covers 2008 onward at horizons 1, 3, 6, and 12. Across
all four horizons, Factor-AR has the lowest equal-weighted average relative RMSE
(about 0.976). Across the Joseph-style 3/6/12 horizons, LASSO ranks first (about
0.966), closely followed by Factor-AR (about 0.968). At h=12, LASSO and Factor-AR
have relative RMSEs of about 0.943 and 0.947, respectively, but their DM tests do
not reject equal predictive accuracy against AR. Rankings vary materially by
horizon and regime. Random Forest, publication lags, the core-variable subset,
and the 24-month horizon remain robustness or extension exercises.

## 9. Frozen robustness hierarchy (18 August 2026)

The robustness specifications below were fixed before their results were
examined.  All completed specifications must be reported; they must not be
selected according to whether they support the primary result.

1. The highest-priority check moves every monthly predictor and inflation lag
   back by one month.  The full seven-model baseline/Random-Forest panel is run
   at h=1/3/6/12; BBIM is checked at its central h=6 horizon and the neural
   network at the h=12 horizon where it has the lowest primary RMSE.
2. A fixed, theory-guided 50-variable core panel is compared with all 111 UK-MD
   predictors at every primary horizon.
3. A rolling 120-month estimation window is compared with the expanding window.
4. AR(2) and AR(6) forecasts are compared with the primary AR(12) benchmark.
5. Random-Forest seed stability is evaluated at h=6 using seeds 61351--61353.
6. BBIM is re-estimated at h=6 without monotonicity constraints.
7. Restricting evaluation to origins from 2018 is derived from the saved primary
   forecasts.  No re-estimation is necessary under an expanding window: those
   forecasts already use the full information available since 1998.
8. The 24-month horizon is optional appendix evidence and is run only after the
   core checks above.

Four-period h=12 regime results remain descriptive.  Target-date regimes are
the primary calendar classification; origin-date and same-regime-window results
are retained to show sensitivity to boundary assignment.  A broad pre-2020
versus 2020-onward comparison is preferred for h=12.

## 10. Robustness progress and common-information-set rule (18 August 2026)

The one-month-lag seven-model panel and all four theory-guided core-panel runs
are complete. In the 50-variable panel, Factor-AR has the lowest h=1 RMSE
(relative RMSE 0.984); LASSO has the lowest h=3 and h=6 RMSEs (0.857 and
0.883); and LASSO and Ridge are effectively tied at h=12 (0.918). Only the
h=6 LASSO-versus-AR raw DM comparison rejects at five per cent (p=0.040), but
not after the pre-specified within-horizon Holm adjustment (p=0.242). These results
must be reported because they were obtained after the hierarchy above was
frozen. They support horizon-dependent predictor usefulness rather than a
universal advantage from either the full or restricted panel.

For the remaining one-month-lag BBIM and neural-network checks, the comparison
AR must come from `outputs/robustness/main_ilag1_full_expanding/predictions.csv`.
Comparing a lagged candidate with the primary zero-lag AR would give the models
different information sets and is not a valid robustness comparison. The
robustness launcher and both specialist scripts now enforce and record the
matched benchmark path. Smoke tests confirm identical realised targets and
forecast dates; smoke estimates are diagnostic only and are excluded from the
formal summary.

Two LASSO convergence warnings occurred during the h=1 core-panel run. They do
not affect the h=3 or h=6 core findings, but final numerical QA should verify
that increasing the iteration ceiling leaves the h=1 forecasts unchanged to a
substantively negligible tolerance. This is a solver diagnostic, not an
additional model selected after observing results.

The focused one-month-information-lag extensions are now complete. At h=6,
BBIM records RMSE 2.176 versus 2.529 for the matched lagged AR (relative RMSE
0.861), with raw Harvey-adjusted DM p=0.0098. Its gain is slightly smaller than
under the zero-lag primary specification (relative RMSE 0.835) but remains
economically large. When BBIM and the six standard lagged candidates are treated
as the single h=6 information-lag testing family, the Holm-adjusted p-value is
0.0686. The result is therefore significant in the pre-specified focused pair
and marginal at ten per cent under family-wise adjustment, not confirmatory at
five per cent after multiplicity correction.

At h=12, the lagged neural network records RMSE 1.895 versus 2.332 for the
matched lagged AR (relative RMSE 0.813), but the raw DM p-value is 0.249 and the
within-family Holm-adjusted value is 1.000. This preserves the economically
large point improvement without supplying evidence that its expected loss is
different from AR. Together, the checks show that the main BBIM and neural-
network patterns are not artifacts of contemporaneous predictor availability,
while the statistical qualification remains essential.

The 120-month rolling-window runs are also complete. Rolling estimation does
not systematically improve forecast accuracy relative to the primary expanding
window. At h=1, all data-rich candidates remain above the rolling AR in RMSE;
Ridge and LASSO deteriorate particularly strongly. At h=3, the naive forecast
has the lowest point RMSE, closely followed by LASSO and Random Forest, but no
candidate rejects equal accuracy with rolling AR. At h=6, LASSO has relative
RMSE 0.871 and raw DM p=0.015 versus rolling AR; the within-horizon Holm value is
0.091. At h=12, Ridge has relative RMSE 0.902 but raw p=0.341. Thus the rolling
results retain horizon-dependent rankings and no comparison survives five-per-
cent Holm correction.

Matched same-model comparisons show why relative RMSE must not be read alone.
The rolling AR is worse than the expanding AR at h=3, h=6 and h=12 by 4.6%,
6.9% and 4.1%, respectively. Rolling LASSO improves on expanding LASSO by 3.6%
at h=6, and rolling Ridge improves by 5.3% at h=12, but neither change is
significant in a direct paired DM test. Conversely, Random Forest becomes 3.2%
worse at h=3 (raw p=0.019; Holm p=0.134), and Factor-AR becomes 11.5% worse at
h=12 (raw p=0.022; Holm p=0.152). No rolling-versus-expanding change survives
family-wise adjustment. The evidence therefore does not support replacing the
expanding primary design with a rolling window.

The alternative-AR-lag check is complete. AR(12), the frozen primary
benchmark, remains the most accurate AR specification at h=1 and h=3. AR(6)
is modestly more accurate at h=6 and h=12: its RMSEs are 2.465 and 2.204,
compared with 2.523 and 2.268 for AR(12). These AR(6)-versus-AR(12)
differences are not significant in paired DM tests (raw p=0.570 and 0.348).
AR(2) is materially worse at h=1 (RMSE 5.138 versus 4.340; Holm-adjusted
p=0.040) and is not a credible replacement for the primary benchmark.

The main economic rankings survive the stronger AR(6) benchmark. BBIM has
relative RMSE 0.901 at h=3, 0.854 at h=6 and 0.896 at h=12. Its raw paired DM
p-values are 0.033, 0.0088 and 0.065, respectively. The neural network remains
the lowest-RMSE h=12 model, with relative RMSE 0.857 against AR(6), although
its raw DM p-value is 0.430. No candidate-versus-alternative-AR comparison
survives a deliberately conservative Holm adjustment across both alternative
lag choices and all candidates at a horizon. Hence the conclusion is not an
artifact of choosing a weak AR(12): BBIM retains a large h=6 point advantage
against the stronger AR(6), while claims of statistical superiority remain
qualified after multiple testing.

Random-Forest seed stability at h=6 is complete. For seeds 61351 (primary),
61352 and 61353, RF RMSE is 2.338, 2.357 and 2.385, respectively; relative
RMSE against the identical AR benchmark is 0.927, 0.934 and 0.945. The
cross-seed mean RMSE is 2.360, the sample standard deviation is 0.024, and the
full range is 0.047. The two alternative-seed forecast paths correlate 0.992
with the primary path, and their mean absolute forecast differences from it
are 0.116 and 0.127 percentage points. Direct paired DM tests against the
primary RF path have raw p-values 0.252 and 0.156 (joint Holm p=0.312).
Therefore RF remains better than AR in point RMSE for every fixed seed, and
its substantive ranking is not driven by a favourable random draw. The seed
61351 result remains the primary result because the seed was fixed ex ante;
the minimum-RMSE seed is not selected retrospectively.

The h=6 BBIM monotonicity check is complete. Removing the theory-guided
monotonicity constraints raises BBIM RMSE from 2.105 to 2.292 and MAE from
1.478 to 1.610, an 8.8% deterioration in each metric. The direct paired DM
test of unconstrained minus constrained BBIM loss gives p=0.032, so the
deterioration is statistically detectable in this focused comparison. The
unconstrained model nevertheless remains 9.2% below AR in RMSE (relative RMSE
0.908), although its DM comparison with AR is not significant (p=0.105).

The direction is also consistent across calendar subsamples. Relative RMSE
against AR changes from 0.870 to 0.919 before Covid, from 0.760 to 0.836 during
Covid, from 0.844 to 0.940 in the high-inflation episode, and from 0.720 to
0.737 during disinflation when constraints are removed. These regime results
are descriptive because each post-2020 period is short. Overall, BBIM's point
advantage is not created solely by the constraints, but the constraints act as
economically meaningful regularisation and account for part of its h=6 gain.
This comparison supports retaining the ex-ante constrained version as primary;
it does not justify selecting constraints after observing forecast errors.

The later-evaluation-sample check is also complete and requires no model
re-estimation. Saved expanding-window forecasts are restricted to forecast
origins from January 2018; their training information remains exactly what was
available at each origin. Sample sizes are 97, 95, 92 and 86 at h=1, h=3, h=6
and h=12. AR remains best at h=1. BBIM ranks first at h=3 (relative RMSE 0.939)
and h=6 (0.823), while the neural network ranks first at h=12 (0.807), followed
by BBIM (0.855). Thus the principal horizon-specific ranking is preserved and
BBIM's h=6 advantage is larger, not smaller, in the later turbulent sample.

For the 2018-origin sample, the raw BBIM-versus-AR DM p-value is 0.045 at h=6
and 0.090 at h=12; the h=12 neural-network p-value is 0.416. None of the eight
candidate comparisons at any horizon survives within-horizon Holm correction
(BBIM h=6 adjusted p=0.360). These are evaluation-sample sensitivity results,
not a newly selected main sample. They support economic stability of the point
rankings while reinforcing the distinction between lower realised RMSE and
formal evidence of lower expected forecast loss.
