r"""Interpret completed BBIM forecasts and selected Random-Forest forecasts.

BBIM interpretation uses the block contributions already saved during the
pseudo-out-of-sample exercise, so no BBIM model is re-estimated.  Random-Forest
TreeSHAP is intentionally limited to representative forecast origins selected
by an ex-ante, evenly-spaced rule within each target-date regime.  Each selected
forest is reconstructed with the hyperparameters stored in the original
forecast row, and its prediction is checked against the saved forecast.

Run from the project root:
    .\.venv\Scripts\python.exe analysis\07_interpretability.py --mode bbim
    .\.venv\Scripts\python.exe analysis\07_interpretability.py --mode both
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.impute import SimpleImputer


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
BBIM_DIR = (
    PROJECT_ROOT
    / "outputs"
    / "bbim_ukmd"
    / "paper_200801_r100_e10_ilag0_plags3_mono"
)
MASTER_DIR = PROJECT_ROOT / "outputs" / "final_master"
OUTPUT_DIR = PROJECT_ROOT / "outputs" / "interpretability"
DATA_DIR = PROJECT_ROOT / "data" / "UKMD_March_2026"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=("bbim", "rf", "both"), default="both")
    parser.add_argument("--rf-horizons", type=int, nargs="+", default=[6])
    parser.add_argument("--origins-per-regime", type=int, default=3)
    parser.add_argument("--bbim-dir", type=Path, default=BBIM_DIR)
    parser.add_argument("--master-dir", type=Path, default=MASTER_DIR)
    parser.add_argument("--data-dir", type=Path, default=DATA_DIR)
    parser.add_argument("--output-dir", type=Path, default=OUTPUT_DIR)
    return parser.parse_args()


def calendar_regime(date: pd.Timestamp) -> str:
    if date < pd.Timestamp("2020-01-01"):
        return "pre_covid"
    if date < pd.Timestamp("2022-01-01"):
        return "covid_2020_2021"
    if date < pd.Timestamp("2024-01-01"):
        return "high_inflation_2022_2023"
    return "disinflation_2024_plus"


def save_bar(
    frame: pd.DataFrame,
    label_column: str,
    value_column: str,
    title: str,
    path: Path,
    top_n: int = 20,
) -> None:
    plot = frame.nlargest(top_n, value_column).sort_values(value_column)
    if plot.empty:
        return
    fig, ax = plt.subplots(figsize=(9, max(4.5, 0.32 * len(plot))))
    ax.barh(plot[label_column], plot[value_column], color="#3465A4")
    ax.set_title(title)
    ax.set_xlabel("Mean absolute contribution")
    ax.grid(axis="x", alpha=0.25)
    fig.tight_layout()
    fig.savefig(path, dpi=220)
    plt.close(fig)


def analyse_bbim(output_dir: Path, bbim_dir: Path) -> None:
    source = bbim_dir / "bbim_predictions_all.csv"
    predictions = pd.read_csv(source, parse_dates=["origin_date", "target_date"])
    rows: list[dict[str, Any]] = []
    audit_rows: list[dict[str, Any]] = []
    for record in predictions.itertuples(index=False):
        contributions = json.loads(record.block_contributions)
        reconstructed = float(sum(contributions.values()))
        audit_rows.append(
            {
                "horizon": int(record.horizon),
                "origin_date": record.origin_date,
                "saved_forecast": float(record.forecast),
                "reconstructed_forecast": reconstructed,
                "absolute_difference": abs(reconstructed - float(record.forecast)),
            }
        )
        for block, contribution in contributions.items():
            rows.append(
                {
                    "horizon": int(record.horizon),
                    "origin_date": record.origin_date,
                    "target_date": record.target_date,
                    "target_regime": calendar_regime(record.target_date),
                    "block": block,
                    "contribution": float(contribution),
                    "absolute_contribution": abs(float(contribution)),
                }
            )
    long = pd.DataFrame(rows)
    audit = pd.DataFrame(audit_rows)
    if audit["absolute_difference"].max() > 1e-8:
        raise ValueError("Saved BBIM block contributions do not reconstruct forecasts")

    nonbaseline = long.loc[long["block"] != "baseline"].copy()
    summary = (
        nonbaseline.groupby(["horizon", "block"], as_index=False)
        .agg(
            n_origins=("origin_date", "nunique"),
            mean_contribution=("contribution", "mean"),
            mean_absolute_contribution=("absolute_contribution", "mean"),
        )
    )
    summary["absolute_share_within_horizon"] = summary[
        "mean_absolute_contribution"
    ] / summary.groupby("horizon")["mean_absolute_contribution"].transform("sum")
    regime_summary = (
        nonbaseline.groupby(["horizon", "target_regime", "block"], as_index=False)
        .agg(
            n_origins=("origin_date", "nunique"),
            mean_contribution=("contribution", "mean"),
            mean_absolute_contribution=("absolute_contribution", "mean"),
        )
    )
    regime_summary["absolute_share_within_cell"] = regime_summary[
        "mean_absolute_contribution"
    ] / regime_summary.groupby(["horizon", "target_regime"])[
        "mean_absolute_contribution"
    ].transform("sum")

    long.to_csv(output_dir / "bbim_block_contributions_long.csv", index=False)
    summary.to_csv(output_dir / "bbim_block_contributions_by_horizon.csv", index=False)
    regime_summary.to_csv(
        output_dir / "bbim_block_contributions_by_horizon_regime.csv", index=False
    )
    audit.to_csv(output_dir / "bbim_contribution_reconstruction_audit.csv", index=False)
    for horizon, subset in summary.groupby("horizon"):
        save_bar(
            subset,
            "block",
            "mean_absolute_contribution",
            f"BBIM block importance, h={horizon}",
            output_dir / f"bbim_block_importance_h{horizon}.png",
            top_n=10,
        )
    print(
        "BBIM block contribution audit: max reconstruction difference = "
        f"{audit['absolute_difference'].max():.3e}"
    )


def evenly_spaced_rows(frame: pd.DataFrame, count: int) -> pd.DataFrame:
    ordered = frame.sort_values("origin_date").reset_index(drop=True)
    if len(ordered) <= count:
        return ordered
    positions = np.linspace(0, len(ordered) - 1, count).round().astype(int)
    return ordered.iloc[np.unique(positions)].copy()


def base_variable(feature: str) -> str:
    return re.sub(r"_lag\d+$", "", feature)


def analyse_random_forest(
    output_dir: Path,
    horizons: list[int],
    origins_per_regime: int,
    master_dir: Path,
    data_dir: Path,
    bbim_dir: Path,
) -> None:
    import shap

    # Importing here keeps the inexpensive BBIM-only mode independent of SHAP.
    from src.forecast_pipeline import build_feature_frames, load_data

    master = pd.read_csv(
        master_dir / "all_model_predictions.csv",
        parse_dates=["origin_date", "target_date"],
    )
    rf = master.loc[
        master["model"].eq("random_forest") & master["horizon"].isin(horizons)
    ].copy()
    if rf.empty:
        raise ValueError(f"No Random-Forest forecasts found for horizons {horizons}")

    selected = pd.concat(
        [
            evenly_spaced_rows(group, origins_per_regime)
            for _, group in rf.groupby(["horizon", "target_regime"], sort=True)
        ],
        ignore_index=True,
    ).sort_values(["horizon", "origin_date"])
    selected.to_csv(output_dir / "rf_shap_selected_origins.csv", index=False)

    data, predictors = load_data(
        data_dir, sorted(set(horizons))
    )
    panel_x, ar_x = build_feature_frames(
        data, predictors, panel_lags=4, ar_lags=12, information_lag=0
    )
    date_to_index = pd.Series(data.index, index=data["Date"]).to_dict()
    block_assignment = pd.read_csv(bbim_dir / "bbim_block_assignment.csv")
    block_map = dict(zip(block_assignment["variable"], block_assignment["block"]))
    block_map.update({"infl_mom_ann": "trend", "infl_yoy": "trend"})

    shap_rows: list[dict[str, Any]] = []
    audit_rows: list[dict[str, Any]] = []
    for record in selected.itertuples(index=False):
        horizon = int(record.horizon)
        origin_idx = int(date_to_index[pd.Timestamp(record.origin_date)])
        latest_train_idx = origin_idx - horizon
        target_col = f"target_h{horizon}"
        train_mask = (
            (data.index <= latest_train_idx)
            & data[target_col].notna()
            & ar_x.notna().any(axis=1)
        )
        train_idx = data.index[train_mask]
        x_train = panel_x.loc[train_idx]
        x_test = panel_x.loc[[origin_idx]]
        y_train = data.loc[train_idx, target_col]

        params = json.loads(record.params)
        model_params = {
            key.removeprefix("model__"): value
            for key, value in params.items()
            if key.startswith("model__")
        }
        imputer = SimpleImputer(strategy="median")
        x_train_imputed = imputer.fit_transform(x_train)
        x_test_imputed = imputer.transform(x_test)
        forest = RandomForestRegressor(
            n_estimators=300,
            n_jobs=1,
            random_state=61351,
            bootstrap=True,
            criterion="squared_error",
            **model_params,
        )
        forest.fit(x_train_imputed, y_train)
        reconstructed_forecast = float(forest.predict(x_test_imputed)[0])

        explanation = shap.TreeExplainer(forest)(x_test_imputed)
        values = np.asarray(explanation.values).reshape(-1)
        expected_value = float(np.asarray(explanation.base_values).reshape(-1)[0])
        shap_forecast = float(expected_value + values.sum())
        audit_rows.append(
            {
                "horizon": horizon,
                "origin_date": record.origin_date,
                "target_regime": record.target_regime,
                "saved_forecast": float(record.forecast),
                "reconstructed_forecast": reconstructed_forecast,
                "shap_reconstructed_forecast": shap_forecast,
                "absolute_saved_difference": abs(
                    reconstructed_forecast - float(record.forecast)
                ),
                "absolute_shap_difference": abs(shap_forecast - reconstructed_forecast),
                "n_train": len(train_idx),
                "params": record.params,
            }
        )
        for position, feature in enumerate(panel_x.columns):
            variable = base_variable(feature)
            shap_rows.append(
                {
                    "horizon": horizon,
                    "origin_date": record.origin_date,
                    "target_date": record.target_date,
                    "target_regime": record.target_regime,
                    "feature": feature,
                    "variable": variable,
                    "block": block_map.get(variable, "unassigned"),
                    "feature_value_imputed": float(x_test_imputed[0, position]),
                    "shap_value": float(values[position]),
                    "absolute_shap_value": abs(float(values[position])),
                }
            )

    audit = pd.DataFrame(audit_rows)
    # The saved predictions must be recovered to numerical precision.  A looser
    # 1e-6 threshold accommodates harmless platform-level tree summation order.
    if audit["absolute_saved_difference"].max() > 1e-6:
        raise ValueError(
            "Reconstructed RF forecasts differ from saved forecasts; do not use SHAP output"
        )
    long = pd.DataFrame(shap_rows)
    # Aggregate lag-level SHAP values within each origin before averaging over
    # origins.  Taking a raw mean across lag-feature rows would understate
    # variables or blocks represented by more features and would make block
    # shares depend on block size in an opaque way.
    variable_origin = (
        long.groupby(
            ["horizon", "origin_date", "target_date", "target_regime", "variable"],
            as_index=False,
        )
        .agg(
            shap_value=("shap_value", "sum"),
            absolute_shap_value=("absolute_shap_value", "sum"),
        )
    )
    variable_summary = (
        variable_origin.groupby(["horizon", "variable"], as_index=False)
        .agg(
            n_origins=("origin_date", "nunique"),
            mean_shap_value=("shap_value", "mean"),
            mean_absolute_shap=("absolute_shap_value", "mean"),
        )
        .sort_values(["horizon", "mean_absolute_shap"], ascending=[True, False])
    )
    variable_regime_summary = (
        variable_origin.groupby(
            ["horizon", "target_regime", "variable"], as_index=False
        )
        .agg(
            n_origins=("origin_date", "nunique"),
            mean_shap_value=("shap_value", "mean"),
            mean_absolute_shap=("absolute_shap_value", "mean"),
        )
        .sort_values(
            ["horizon", "target_regime", "mean_absolute_shap"],
            ascending=[True, True, False],
        )
    )
    block_origin = (
        long.groupby(
            ["horizon", "origin_date", "target_date", "target_regime", "block"],
            as_index=False,
        )
        .agg(
            shap_value=("shap_value", "sum"),
            absolute_shap_value=("absolute_shap_value", "sum"),
        )
    )
    block_summary = (
        block_origin.groupby(["horizon", "target_regime", "block"], as_index=False)
        .agg(
            n_origins=("origin_date", "nunique"),
            mean_shap_value=("shap_value", "mean"),
            mean_absolute_shap=("absolute_shap_value", "mean"),
        )
    )
    block_summary["absolute_share_within_cell"] = block_summary[
        "mean_absolute_shap"
    ] / block_summary.groupby(["horizon", "target_regime"])[
        "mean_absolute_shap"
    ].transform("sum")

    long.to_csv(output_dir / "rf_shap_values_long.csv", index=False)
    variable_origin.to_csv(output_dir / "rf_shap_variable_origin.csv", index=False)
    variable_summary.to_csv(output_dir / "rf_shap_variable_summary.csv", index=False)
    variable_regime_summary.to_csv(
        output_dir / "rf_shap_variable_regime_summary.csv", index=False
    )
    block_origin.to_csv(output_dir / "rf_shap_block_origin.csv", index=False)
    block_summary.to_csv(output_dir / "rf_shap_block_regime_summary.csv", index=False)
    audit.to_csv(output_dir / "rf_shap_reconstruction_audit.csv", index=False)
    for horizon, subset in variable_summary.groupby("horizon"):
        save_bar(
            subset,
            "variable",
            "mean_absolute_shap",
            f"Random Forest TreeSHAP importance, h={horizon}",
            output_dir / f"rf_shap_top_variables_h{horizon}.png",
        )
    print(
        "RF reconstruction audit: max saved-prediction difference = "
        f"{audit['absolute_saved_difference'].max():.3e}; "
        "max SHAP additivity difference = "
        f"{audit['absolute_shap_difference'].max():.3e}"
    )


def main() -> None:
    args = parse_args()
    output_dir = args.output_dir.resolve()
    bbim_dir = args.bbim_dir.resolve()
    master_dir = args.master_dir.resolve()
    data_dir = args.data_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    if args.mode in {"bbim", "both"}:
        analyse_bbim(output_dir, bbim_dir)
    if args.mode in {"rf", "both"}:
        analyse_random_forest(
            output_dir,
            horizons=sorted(set(args.rf_horizons)),
            origins_per_regime=args.origins_per_regime,
            master_dir=master_dir,
            data_dir=data_dir,
            bbim_dir=bbim_dir,
        )
    print(f"Saved interpretability outputs to: {output_dir}")


if __name__ == "__main__":
    main()
