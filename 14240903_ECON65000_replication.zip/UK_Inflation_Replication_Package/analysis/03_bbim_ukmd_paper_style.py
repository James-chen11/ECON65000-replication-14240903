r"""Paper-style Blockwise Boosted Inflation Model adapted to UK-MD.

This is an algorithmic adaptation of Buckmann, Potjagailo and Schnattinger
(2025), not an exact empirical replication: the original paper uses a richer
and partly proprietary indicator set, whereas this script assigns every
available March-2026 UK-MD predictor to one of five economic blocks.

The file is also a VS Code/Jupyter percent-format notebook: each ``# %%`` line
starts a cell.  It can therefore be copied cell-by-cell into an ``.ipynb``.

Core paper-style choices
------------------------
* five additive economic blocks;
* a fresh random ordering of blocks in every boosting round;
* one XGBoost tree per block and round, fitted to the latest residual;
* external learning rate 0.02;
* random 50% of observations and 25% of within-block features per tree;
* depth three and minimum child weight five;
* 2% initial forecast;
* ten models, each fitted to a random 80% training subsample;
* 100 boosting rounds and re-estimation every three forecast origins;
* direct expanding-window pseudo-out-of-sample forecasts.

Run examples from the project root
----------------------------------
Quick installation/logic check (default):
    .\.venv\Scripts\python.exe analysis\03_bbim_ukmd_paper_style.py --mode smoke

Moderate pilot before committing to the long run:
    .\.venv\Scripts\python.exe analysis\03_bbim_ukmd_paper_style.py --mode pilot

Paper-style full exercise, one horizon at a time:
    .\.venv\Scripts\python.exe analysis\03_bbim_ukmd_paper_style.py --mode paper --horizons 1
    .\.venv\Scripts\python.exe analysis\03_bbim_ukmd_paper_style.py --mode paper --horizons 3
    .\.venv\Scripts\python.exe analysis\03_bbim_ukmd_paper_style.py --mode paper --horizons 6
    .\.venv\Scripts\python.exe analysis\03_bbim_ukmd_paper_style.py --mode paper --horizons 12
"""

# %% 1. Imports / 导入库
from __future__ import annotations

import argparse
import json
import math
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from scipy import stats
from sklearn.impute import SimpleImputer
from xgboost import XGBRegressor


# %% 2. Configuration / 参数设置
RANDOM_SEED = 61351


@dataclass(frozen=True)
class RunConfig:
    """All settings required to reproduce one run."""

    mode: str
    horizons: tuple[int, ...]
    oos_start: str
    information_lag: int
    predictor_lags: int
    min_train: int
    n_rounds: int
    ensemble_size: int
    ensemble_train_fraction: float
    row_fraction: float
    feature_fraction: float
    learning_rate: float
    max_depth: int
    min_child_weight: float
    baseline: float
    retrain_every: int
    use_monotone_constraints: bool
    max_origins: int | None
    random_seed: int


def make_config(args: argparse.Namespace) -> RunConfig:
    """Translate smoke/pilot/paper mode into explicit settings."""
    if args.mode == "smoke":
        defaults = dict(
            horizons=(12,),
            oos_start="2024-01-01",
            n_rounds=3,
            ensemble_size=2,
            max_origins=3,
        )
    elif args.mode == "pilot":
        defaults = dict(
            horizons=(3, 6, 12),
            oos_start="2020-01-01",
            n_rounds=30,
            ensemble_size=5,
            max_origins=None,
        )
    else:
        defaults = dict(
            horizons=(1, 3, 6, 12),
            oos_start="2008-01-01",
            n_rounds=100,
            ensemble_size=10,
            max_origins=None,
        )

    return RunConfig(
        mode=args.mode,
        horizons=tuple(args.horizons or defaults["horizons"]),
        oos_start=args.oos_start or defaults["oos_start"],
        information_lag=args.information_lag,
        predictor_lags=args.predictor_lags,
        min_train=args.min_train,
        n_rounds=args.rounds or defaults["n_rounds"],
        ensemble_size=args.ensemble_size or defaults["ensemble_size"],
        ensemble_train_fraction=0.80,
        row_fraction=0.50,
        feature_fraction=0.25,
        learning_rate=0.02,
        max_depth=3,
        min_child_weight=5.0,
        baseline=2.0,
        retrain_every=3,
        use_monotone_constraints=not args.no_monotone,
        max_origins=(
            args.max_origins
            if args.max_origins is not None
            else defaults["max_origins"]
        ),
        random_seed=RANDOM_SEED,
    )


# %% 3. Load UK-MD and construct the direct inflation targets
#       读取UK-MD并构建直接多步预测目标
def load_ukmd(
    project_root: Path,
    horizons: tuple[int, ...],
) -> tuple[pd.DataFrame, list[str]]:
    """Load provider-transformed predictors and the raw headline CPI index."""
    data_dir = project_root / "data" / "UKMD_March_2026"
    raw = pd.read_csv(data_dir / "raw_uk_md.csv")
    balanced = pd.read_csv(data_dir / "balanced_uk_md.csv")

    for frame in (raw, balanced):
        frame.drop(columns=["Unnamed: 0"], errors="ignore", inplace=True)

    # The raw file contains a provider transformation-code row.
    raw = raw.loc[raw["Date"].astype(str) != "Transform"].copy()
    raw["Date"] = pd.to_datetime(raw["Date"], errors="raise")
    balanced["Date"] = pd.to_datetime(balanced["Date"], errors="raise")
    raw.sort_values("Date", inplace=True)
    balanced.sort_values("Date", inplace=True)

    predictor_cols = [c for c in balanced.columns if c != "Date"]
    balanced[predictor_cols] = balanced[predictor_cols].apply(
        pd.to_numeric, errors="coerce"
    )
    raw["CPI_ALL"] = pd.to_numeric(raw["CPI_ALL"], errors="coerce")

    cpi = raw[["Date", "CPI_ALL"]].dropna().copy()
    cpi.rename(columns={"CPI_ALL": "CPI_ALL_INDEX"}, inplace=True)
    log_cpi = np.log(cpi["CPI_ALL_INDEX"])
    cpi["infl_yoy"] = 100.0 * log_cpi.diff(12)
    for horizon in horizons:
        # Annualised average inflation between t and t+h.
        cpi[f"target_h{horizon}"] = (1200.0 / horizon) * (
            log_cpi.shift(-horizon) - log_cpi
        )

    data = balanced.merge(cpi, on="Date", how="left", validate="one_to_one")
    data.replace([np.inf, -np.inf], np.nan, inplace=True)
    return data.reset_index(drop=True), predictor_cols


# %% 4. Put every UK-MD predictor into one of the five BBIM blocks
#       将全部UK-MD变量划分到五个经济板块
BBIM_BLOCK_DEFINITIONS: dict[str, dict[str, str]] = {
    "trend": {
        "economic_content": (
            "Consumer and retail price indices capturing inflation persistence "
            "and the composition of observed price changes."
        ),
        "assignment_basis": (
            "CPI, CPIH and RPI aggregates or components in the UK-MD metadata."
        ),
    },
    "global_demand": {
        "economic_content": (
            "External trade, foreign financial conditions and global activity "
            "or uncertainty indicators that proxy overseas demand."
        ),
        "assignment_basis": (
            "Export/import volumes excluding commodity-cost series, together "
            "with global equity, volatility, uncertainty and leading indicators."
        ),
    },
    "domestic_demand": {
        "economic_content": (
            "UK labour utilisation, spending and activity, credit, monetary and "
            "domestic financial conditions, and business or consumer surveys."
        ),
        "assignment_basis": (
            "UK-MD series whose main forecasting channel is domestic expenditure "
            "or financing conditions rather than production costs."
        ),
    },
    "global_supply": {
        "economic_content": (
            "Imported cost pressure from energy, commodities, raw materials, "
            "exchange rates and externally priced producer inputs."
        ),
        "assignment_basis": (
            "Fuel, oil, metal and raw-material trade or price series plus sterling "
            "exchange-rate indices in the UK-MD metadata."
        ),
    },
    "domestic_supply": {
        "economic_content": (
            "UK wage costs, labour-market tightness, production capacity or output, "
            "and domestically produced input prices."
        ),
        "assignment_basis": (
            "Earnings, vacancies, industrial production and UK manufacturing PPI "
            "series in the UK-MD metadata."
        ),
    },
}


def make_ukmd_blocks(predictor_cols: list[str]) -> dict[str, list[str]]:
    """Return a mutually exclusive and exhaustive five-block assignment.

    The five labels follow the architecture of Buckmann, Potjagailo and
    Schnattinger (2025). Individual variables are this dissertation's ex-ante,
    theory-guided adaptation based on UK-MD series definitions and the economic
    channel documented in ``BBIM_BLOCK_DEFINITIONS``; they are not copied from
    the original paper's different indicator set. The grouping follows economic
    content rather than column position. An exception is raised if a current
    UK-MD variable is duplicated, omitted or unknown, so the mapping remains
    mutually exclusive, exhaustive and auditable.
    """
    blocks: dict[str, list[str]] = {
        "trend": [
            "CPIH_ALL", "CPI_ALL", "CPI_EX_ENER", "CPI_GOOD", "CPI_DUR",
            "CPI_NON_DUR", "CPI_SERV", "CPI_CLOTH", "CPI_TRANS", "RPI_ALL",
            "RPI_GOOD", "RPI_SERV", "RPI_HOUSE",
        ],
        "global_demand": [
            "EXP_TOT", "EXP_GOOD", "IMP_ALL", "IMP_GOOD", "EXP_MACH",
            "IMP_MACH", "SP500", "VIX", "EUR_UNC_INDEX", "CLI",
        ],
        "domestic_demand": [
            "EMP", "EMP_PART", "EMP_TEMP", "UNEMP_RATE", "UNEMP_DURA_6mth",
            "UNEMP_DURA_6.12mth", "UNEMP_DURA_12mth.", "UNEMP_DURA_24mth.",
            "EMP_RATE", "EMP_ACT", "EMP_ACT_RATE", "CLAIMS", "CLAIMS_RATE",
            "TOT_WEEK_HRS", "AVG_WEEK_HRS", "AVG_WEEK_HRS_FULL", "IOS",
            "IOS_45", "IOS_46", "IOS_47", "IOS_G", "IOS_EDUC", "IOS_PNDS",
            "RSI", "CAR_REGIS", "RETAIL_TRADE_INDEX", "AVG_WEEK_RETAIL_SALE",
            "AVG_WEEK_RETAIL_SALE_NON_FOOD", "BANK_RATE",
            "CONS_CREDIT_ex_student_loan", "TOT_LENDING_APP", "TOT_HOUSE_APP",
            "MORT_FIXED_RATE_5YRS", "MORT_FIXED_RATE_2YRS", "M1", "M2", "M3",
            "M4", "LIBOR_3mth", "SONIA", "BGS_5yrs_yld", "BGS_10yrs_yld",
            "BGS_20yrs_yld", "FTSE_ALL", "FTSE250", "UK_focused_equity",
            "BCI", "CCI",
        ],
        "global_supply": [
            "EXP_FUEL", "IMP_FUEL", "EXP_OIL", "IMP_OIL", "EXP_METAL",
            "IMP_METAL", "EXP_CRUDE_MAT", "IMP_CRUDE_MAT", "GBP_BROAD",
            "GBP_CAN", "GBP_EUR", "GBP_JAP", "GBP_US", "OIL_PRICE",
            "PPI_OIL", "PPI_METAL",
        ],
        "domestic_supply": [
            "AWE_ALL", "AWE_CONS", "AWE_MANU", "AWE_PRIV", "AWE_PUB",
            "AWE_SERV", "VAC_TOT", "VAC_CONS", "VAC_MANU", "IOP_PROD",
            "IOP_CAP_GOOD", "IOP_DUR", "IOP_ENER", "IOP_GOOD",
            "IOP_INT_GOOD", "IOP_MACH", "IOP_MANU", "IOP_MINE",
            "IOP_NON_DUR", "IOP_PETRO", "IOP_OIL_EXTRACT", "PPI_MANU",
            "PPI_MACH", "PPI_MOTOR",
        ],
    }

    assigned = [c for values in blocks.values() for c in values]
    duplicates = sorted({c for c in assigned if assigned.count(c) > 1})
    missing = sorted(set(predictor_cols) - set(assigned))
    unknown = sorted(set(assigned) - set(predictor_cols))
    if duplicates or missing or unknown:
        raise ValueError(
            "Invalid BBIM block map. "
            f"duplicates={duplicates}; missing={missing}; unknown={unknown}"
        )
    return blocks


def save_block_audit(
    blocks: dict[str, list[str]],
    output_dir: Path,
) -> None:
    rows = [
        {
            "block": block,
            "variable": variable,
            "economic_content": BBIM_BLOCK_DEFINITIONS[block]["economic_content"],
            "assignment_basis": BBIM_BLOCK_DEFINITIONS[block]["assignment_basis"],
        }
        for block, variables in blocks.items()
        for variable in variables
    ]
    pd.DataFrame(rows).to_csv(output_dir / "bbim_block_assignment.csv", index=False)


# %% 5. Create contemporaneous plus two lagged versions within each block
#       为每个板块构建当期值和两个滞后值
def make_lagged_features(
    data: pd.DataFrame,
    blocks: dict[str, list[str]],
    information_lag: int,
    predictor_lags: int,
) -> tuple[pd.DataFrame, dict[str, list[str]]]:
    """Use lag 0,1,2 by default; set information_lag=1 for a release-lag check."""
    base_columns = [c for values in blocks.values() for c in values]
    feature_parts: list[pd.DataFrame] = []
    lagged_blocks = {block: [] for block in blocks}

    for lag in range(information_lag, information_lag + predictor_lags):
        shifted = data[base_columns].shift(lag)
        shifted.columns = [f"{c}_lag{lag}" for c in base_columns]
        feature_parts.append(shifted)
        for block, variables in blocks.items():
            lagged_blocks[block].extend(f"{c}_lag{lag}" for c in variables)

    features = pd.concat(feature_parts, axis=1)
    return features, lagged_blocks


# %% 6. Conservative theory-based monotonicity constraints
#       保守的理论单调约束
def make_monotone_signs(
    lagged_blocks: dict[str, list[str]],
) -> dict[str, dict[str, int]]:
    """Constrain only relationships whose direction is reasonably clear.

    A sign of +1 means that a larger transformed predictor cannot reduce the
    fitted inflation contribution; -1 means it cannot increase it; omitted
    variables remain unconstrained.  Ambiguous output, interest-rate and asset
    price relationships are deliberately left at zero.
    """
    positive_bases = {
        # Inflation persistence and cost indicators.
        "CPIH_ALL", "CPI_ALL", "CPI_EX_ENER", "CPI_GOOD", "CPI_DUR",
        "CPI_NON_DUR", "CPI_SERV", "CPI_CLOTH", "CPI_TRANS", "RPI_ALL",
        "RPI_GOOD", "RPI_SERV", "RPI_HOUSE", "AWE_ALL", "AWE_CONS",
        "AWE_MANU", "AWE_PRIV", "AWE_PUB", "AWE_SERV", "VAC_TOT",
        "VAC_CONS", "VAC_MANU", "OIL_PRICE", "PPI_OIL", "PPI_METAL",
        "PPI_MANU", "PPI_MACH", "PPI_MOTOR",
        # Selected demand/activity indicators.
        "EMP", "EMP_PART", "EMP_TEMP", "EMP_RATE", "TOT_WEEK_HRS",
        "AVG_WEEK_HRS", "AVG_WEEK_HRS_FULL", "RSI", "CAR_REGIS",
        "RETAIL_TRADE_INDEX", "AVG_WEEK_RETAIL_SALE",
        "AVG_WEEK_RETAIL_SALE_NON_FOOD", "CONS_CREDIT_ex_student_loan",
        "TOT_LENDING_APP", "TOT_HOUSE_APP", "BCI", "CCI", "CLI",
    }
    negative_bases = {
        "UNEMP_RATE", "UNEMP_DURA_6mth", "UNEMP_DURA_6.12mth",
        "UNEMP_DURA_12mth.", "UNEMP_DURA_24mth.", "CLAIMS", "CLAIMS_RATE",
        # A rise in these GBP indices is interpreted as sterling appreciation.
        "GBP_BROAD", "GBP_CAN", "GBP_EUR", "GBP_JAP", "GBP_US",
    }

    signs: dict[str, dict[str, int]] = {block: {} for block in lagged_blocks}
    for block, features in lagged_blocks.items():
        for feature in features:
            base = feature.rsplit("_lag", 1)[0]
            if base in positive_bases:
                signs[block][feature] = 1
            elif base in negative_bases:
                signs[block][feature] = -1
    return signs


# %% 7. One additive blockwise boosted model / 单个BBIM子模型
@dataclass
class FittedBlockTree:
    block: str
    features: list[str]
    model: Any


class BlockwiseBoostedInflationRegressor:
    """Additive blockwise boosting with one XGBoost tree per block and round."""

    def __init__(
        self,
        blocks: dict[str, list[str]],
        monotone_signs: dict[str, dict[str, int]] | None,
        n_rounds: int,
        learning_rate: float,
        row_fraction: float,
        feature_fraction: float,
        max_depth: int,
        min_child_weight: float,
        baseline: float,
        random_state: int,
    ) -> None:
        self.blocks = blocks
        self.monotone_signs = monotone_signs or {}
        self.n_rounds = n_rounds
        self.learning_rate = learning_rate
        self.row_fraction = row_fraction
        self.feature_fraction = feature_fraction
        self.max_depth = max_depth
        self.min_child_weight = min_child_weight
        self.baseline = baseline
        self.random_state = random_state

    def fit(
        self,
        x: pd.DataFrame,
        y: pd.Series | np.ndarray,
    ) -> "BlockwiseBoostedInflationRegressor":
        y_array = np.asarray(y, dtype=float)
        if len(x) != len(y_array) or not np.isfinite(y_array).all():
            raise ValueError("Training x/y are misaligned or y is non-finite.")

        self.feature_names_in_ = list(x.columns)
        self.blocks_ = {
            block: [c for c in columns if c in self.feature_names_in_]
            for block, columns in self.blocks.items()
        }
        self.blocks_ = {k: v for k, v in self.blocks_.items() if v}
        if len(self.blocks_) != 5:
            raise ValueError(f"Expected five non-empty blocks, found {self.blocks_.keys()}")

        self.imputer_ = SimpleImputer(strategy="median", keep_empty_features=True)
        x_imp = pd.DataFrame(
            self.imputer_.fit_transform(x),
            index=x.index,
            columns=self.feature_names_in_,
        )

        rng = np.random.default_rng(self.random_state)
        n_obs = len(x_imp)
        prediction = np.full(n_obs, self.baseline, dtype=float)
        self.trees_: list[FittedBlockTree] = []
        self.training_loss_: list[float] = []

        for boosting_round in range(self.n_rounds):
            for block in rng.permutation(list(self.blocks_)):
                candidates = self.blocks_[block]
                n_features = max(1, math.ceil(self.feature_fraction * len(candidates)))
                selected_features = list(
                    rng.choice(candidates, size=n_features, replace=False)
                )
                n_rows = min(
                    n_obs,
                    max(10, math.ceil(self.row_fraction * n_obs)),
                )
                selected_rows = rng.choice(n_obs, size=n_rows, replace=False)
                residual = y_array - prediction

                block_signs = self.monotone_signs.get(block, {})
                constraints = tuple(
                    int(block_signs.get(feature, 0))
                    for feature in selected_features
                )

                # n_estimators=1 and internal learning_rate=1 create one tree.
                # Shrinkage is applied externally when its prediction is added.
                tree = XGBRegressor(
                    objective="reg:squarederror",
                    n_estimators=1,
                    learning_rate=1.0,
                    base_score=0.0,
                    max_depth=self.max_depth,
                    min_child_weight=self.min_child_weight,
                    subsample=1.0,
                    colsample_bytree=1.0,
                    reg_lambda=1.0,
                    reg_alpha=0.0,
                    monotone_constraints=constraints,
                    tree_method="hist",
                    n_jobs=1,
                    random_state=self.random_state + len(self.trees_),
                    verbosity=0,
                )
                tree.fit(
                    x_imp.iloc[selected_rows][selected_features],
                    residual[selected_rows],
                )
                update = tree.predict(x_imp[selected_features])
                prediction += self.learning_rate * update
                self.trees_.append(
                    FittedBlockTree(block, selected_features, tree)
                )

            self.training_loss_.append(float(np.mean((y_array - prediction) ** 2)))

        self.fitted_values_ = prediction
        return self

    def _impute(self, x: pd.DataFrame) -> pd.DataFrame:
        missing = sorted(set(self.feature_names_in_) - set(x.columns))
        if missing:
            raise ValueError(f"Prediction frame is missing: {missing[:8]}")
        return pd.DataFrame(
            self.imputer_.transform(x[self.feature_names_in_]),
            index=x.index,
            columns=self.feature_names_in_,
        )

    def predict(self, x: pd.DataFrame) -> np.ndarray:
        x_imp = self._impute(x)
        prediction = np.full(len(x_imp), self.baseline, dtype=float)
        for fitted in self.trees_:
            prediction += self.learning_rate * fitted.model.predict(
                x_imp[fitted.features]
            )
        return prediction

    def block_contributions(self, x: pd.DataFrame) -> pd.DataFrame:
        x_imp = self._impute(x)
        result = pd.DataFrame(0.0, index=x.index, columns=list(self.blocks_))
        for fitted in self.trees_:
            result[fitted.block] += self.learning_rate * fitted.model.predict(
                x_imp[fitted.features]
            )
        result.insert(0, "baseline", self.baseline)
        result["forecast"] = result.sum(axis=1)
        return result


# %% 8. Ten-model outer ensemble / 十模型外层集成
class BBIMEnsemble:
    """Average BBIMs fitted to independent 80% training subsamples."""

    def __init__(
        self,
        blocks: dict[str, list[str]],
        monotone_signs: dict[str, dict[str, int]],
        config: RunConfig,
        random_state: int,
    ) -> None:
        self.blocks = blocks
        self.monotone_signs = monotone_signs
        self.config = config
        self.random_state = random_state

    def fit(self, x: pd.DataFrame, y: pd.Series) -> "BBIMEnsemble":
        rng = np.random.default_rng(self.random_state)
        self.models_: list[BlockwiseBoostedInflationRegressor] = []
        n_outer = min(
            len(x),
            max(30, math.ceil(self.config.ensemble_train_fraction * len(x))),
        )

        for model_number in range(self.config.ensemble_size):
            selected_positions = np.sort(
                rng.choice(len(x), size=n_outer, replace=False)
            )
            selected_index = x.index[selected_positions]
            model = BlockwiseBoostedInflationRegressor(
                blocks=self.blocks,
                monotone_signs=(
                    self.monotone_signs
                    if self.config.use_monotone_constraints
                    else {}
                ),
                n_rounds=self.config.n_rounds,
                learning_rate=self.config.learning_rate,
                row_fraction=self.config.row_fraction,
                feature_fraction=self.config.feature_fraction,
                max_depth=self.config.max_depth,
                min_child_weight=self.config.min_child_weight,
                baseline=self.config.baseline,
                random_state=self.random_state + 10_000 * model_number,
            )
            model.fit(x.loc[selected_index], y.loc[selected_index])
            self.models_.append(model)
        return self

    def predict(self, x: pd.DataFrame) -> np.ndarray:
        return np.mean([model.predict(x) for model in self.models_], axis=0)

    def block_contributions(self, x: pd.DataFrame) -> pd.DataFrame:
        frames = [model.block_contributions(x) for model in self.models_]
        return sum(frames[1:], frames[0].copy()) / len(frames)

    @property
    def mean_final_training_mse(self) -> float:
        return float(np.mean([m.training_loss_[-1] for m in self.models_]))


# %% 9. Pseudo-out-of-sample forecasting with three-month retraining
#       每三个月重新估计的扩展窗口伪样本外预测
def calendar_regime(target_date: pd.Timestamp) -> str:
    if target_date < pd.Timestamp("2020-01-01"):
        return "pre_covid"
    if target_date < pd.Timestamp("2022-01-01"):
        return "covid"
    if target_date < pd.Timestamp("2024-01-01"):
        # Match the label used by the completed baseline forecast pipeline.
        return "high_inflation_episode"
    return "disinflation"


def run_one_horizon(
    data: pd.DataFrame,
    features: pd.DataFrame,
    lagged_blocks: dict[str, list[str]],
    monotone_signs: dict[str, dict[str, int]],
    horizon: int,
    config: RunConfig,
    checkpoint_path: Path,
) -> pd.DataFrame:
    """Run one direct horizon and checkpoint after each retraining batch."""
    target = data[f"target_h{horizon}"]
    possible = data.index[
        (data["Date"] >= pd.Timestamp(config.oos_start)) & target.notna()
    ].tolist()
    if config.max_origins is not None:
        possible = possible[-config.max_origins :]

    existing = pd.DataFrame()
    if checkpoint_path.exists():
        existing = pd.read_csv(
            checkpoint_path,
            parse_dates=[
                "origin_date", "target_date", "latest_train_origin_date",
                "latest_train_target_date",
            ],
        )

    completed_dates = set(
        pd.to_datetime(existing.get("origin_date", pd.Series(dtype=str)))
    )
    rows = existing.to_dict("records") if not existing.empty else []
    total_batches = math.ceil(len(possible) / config.retrain_every)

    for batch_number, start in enumerate(
        range(0, len(possible), config.retrain_every), start=1
    ):
        batch = possible[start : start + config.retrain_every]
        batch_dates = [pd.Timestamp(data.at[i, "Date"]) for i in batch]
        if all(date in completed_dates for date in batch_dates):
            print(
                f"h={horizon} batch {batch_number}/{total_batches}: checkpoint found",
                flush=True,
            )
            continue

        # If a previous run stopped inside a batch, recompute the entire batch
        # so that the three-month retraining schedule remains unchanged.
        batch_date_set = set(batch_dates)
        rows = [r for r in rows if pd.Timestamp(r["origin_date"]) not in batch_date_set]

        fit_origin_idx = batch[0]
        latest_train_idx = fit_origin_idx - horizon
        train_idx = target.index[
            (target.index <= latest_train_idx) & target.notna()
        ]
        if len(train_idx) < config.min_train:
            continue

        started = time.perf_counter()
        ensemble = BBIMEnsemble(
            blocks=lagged_blocks,
            monotone_signs=monotone_signs,
            config=config,
            random_state=config.random_seed + 100_000 * horizon + fit_origin_idx,
        )
        ensemble.fit(features.loc[train_idx], target.loc[train_idx])
        fit_minutes = (time.perf_counter() - started) / 60.0

        latest_train_origin = pd.Timestamp(data.at[train_idx[-1], "Date"])
        for origin_idx in batch:
            origin_date = pd.Timestamp(data.at[origin_idx, "Date"])
            target_date = origin_date + pd.DateOffset(months=horizon)
            x_origin = features.loc[[origin_idx]]
            forecast = float(ensemble.predict(x_origin)[0])
            contributions = ensemble.block_contributions(x_origin).iloc[0]
            actual = float(target.loc[origin_idx])
            rows.append(
                {
                    "origin_date": origin_date,
                    "target_date": target_date,
                    "latest_train_origin_date": latest_train_origin,
                    "latest_train_target_date": (
                        latest_train_origin + pd.DateOffset(months=horizon)
                    ),
                    "horizon": horizon,
                    "model": "bbim_ukmd",
                    "actual": actual,
                    "forecast": forecast,
                    "error": actual - forecast,
                    "calendar_regime": calendar_regime(target_date),
                    "n_train": len(train_idx),
                    "n_ensemble": config.ensemble_size,
                    "n_rounds": config.n_rounds,
                    "trees_per_model": config.n_rounds * len(lagged_blocks),
                    "mean_final_training_mse": ensemble.mean_final_training_mse,
                    "fit_minutes": fit_minutes,
                    "block_contributions": json.dumps(
                        {
                            key: float(value)
                            for key, value in contributions.items()
                            if key != "forecast"
                        },
                        sort_keys=True,
                    ),
                }
            )

        result = pd.DataFrame(rows).sort_values("origin_date").reset_index(drop=True)
        result.to_csv(checkpoint_path, index=False)
        completed_dates.update(batch_dates)
        print(
            f"h={horizon} batch {batch_number}/{total_batches}: "
            f"{batch_dates[0]:%Y-%m} to {batch_dates[-1]:%Y-%m}; "
            f"train={len(train_idx)}; fit={fit_minutes:.2f} min",
            flush=True,
        )

    return pd.DataFrame(rows).sort_values("origin_date").reset_index(drop=True)


# %% 10. RMSE/MAE and Harvey-adjusted DM tests against AR
#        计算误差指标及相对AR的Harvey修正DM检验
def harvey_dm_test(
    actual: np.ndarray,
    forecast_model: np.ndarray,
    forecast_ar: np.ndarray,
    horizon: int,
) -> tuple[float, float, float]:
    """Two-sided DM test; positive loss difference means the model beats AR."""
    e_model = np.asarray(actual) - np.asarray(forecast_model)
    e_ar = np.asarray(actual) - np.asarray(forecast_ar)
    differential = e_ar**2 - e_model**2
    differential = differential[np.isfinite(differential)]
    n = len(differential)
    if n < max(8, horizon + 3):
        return np.nan, np.nan, float(np.mean(differential)) if n else np.nan

    centered = differential - differential.mean()
    max_lag = min(horizon - 1, n - 2)
    long_run_variance = float(np.dot(centered, centered) / n)
    for lag in range(1, max_lag + 1):
        covariance = float(np.dot(centered[lag:], centered[:-lag]) / n)
        weight = 1.0 - lag / (max_lag + 1.0)
        long_run_variance += 2.0 * weight * covariance
    if not np.isfinite(long_run_variance) or long_run_variance <= 0:
        return np.nan, np.nan, float(differential.mean())

    dm = float(differential.mean() / np.sqrt(long_run_variance / n))
    harvey_term = (n + 1 - 2 * horizon + horizon * (horizon - 1) / n) / n
    if harvey_term <= 0:
        return np.nan, np.nan, float(differential.mean())
    dm_harvey = dm * np.sqrt(harvey_term)
    p_value = float(2.0 * stats.t.sf(abs(dm_harvey), df=n - 1))
    return float(dm_harvey), p_value, float(differential.mean())


def evaluate_against_existing_models(
    bbim_predictions: pd.DataFrame,
    project_root: Path,
    output_dir: Path,
    benchmark_predictions: Path | None = None,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Match BBIM forecasts to the already completed baseline forecast dates."""
    baseline_path = benchmark_predictions or (
        project_root / "outputs" / "full_with_random_forest" / "predictions.csv"
    )
    if not baseline_path.exists():
        print("Baseline predictions not found; BBIM forecasts were still saved.")
        return pd.DataFrame(), pd.DataFrame(), pd.DataFrame()

    baseline = pd.read_csv(
        baseline_path,
        parse_dates=["origin_date", "target_date"],
    )
    if "calendar_regime" not in baseline.columns:
        baseline["calendar_regime"] = baseline["target_date"].map(calendar_regime)
    if "error" not in baseline.columns:
        baseline["error"] = baseline["actual"] - baseline["forecast"]
    # Recreate BBIM regime labels from target dates.  This also repairs
    # checkpoints produced by an earlier version that used "high_inflation"
    # instead of the baseline pipeline's "high_inflation_episode" label.
    bbim_predictions = bbim_predictions.copy()
    bbim_predictions["calendar_regime"] = bbim_predictions["target_date"].map(
        calendar_regime
    )
    keep = [
        "origin_date", "target_date", "horizon", "model", "actual",
        "forecast", "error", "calendar_regime",
    ]
    combined = pd.concat(
        [baseline[keep], bbim_predictions[keep]],
        ignore_index=True,
    )
    combined.to_csv(output_dir / "predictions_all_models_with_bbim.csv", index=False)

    # Standard output for the common robustness summariser. The benchmark AR
    # must be estimated under the same information-set specification as BBIM.
    valid_keys = bbim_predictions[["horizon", "origin_date"]].drop_duplicates()
    standard = combined.loc[
        combined["model"].isin(["ar", "bbim_ukmd"])
    ].merge(valid_keys, on=["horizon", "origin_date"], how="inner")
    standard["error"] = standard["actual"] - standard["forecast"]
    standard.to_csv(output_dir / "predictions.csv", index=False)

    metric_rows: list[dict[str, Any]] = []
    dm_rows: list[dict[str, Any]] = []
    regime_rows: list[dict[str, Any]] = []

    # All models are evaluated on exactly the dates for which BBIM forecasts
    # exist.  This matters in smoke/pilot runs and prevents a short BBIM sample
    # from being compared with the AR RMSE from the full 2008-present sample.
    for horizon, unbalanced_horizon_data in combined.groupby("horizon"):
        bbim_dates = set(
            unbalanced_horizon_data.loc[
                unbalanced_horizon_data["model"] == "bbim_ukmd", "origin_date"
            ]
        )
        if not bbim_dates:
            continue
        horizon_data = unbalanced_horizon_data.loc[
            unbalanced_horizon_data["origin_date"].isin(bbim_dates)
        ].copy()
        ar = horizon_data.loc[
            horizon_data["model"] == "ar",
            ["origin_date", "actual", "forecast"],
        ].rename(columns={"forecast": "forecast_ar"})
        ar_rmse = float(np.sqrt(np.mean((ar["actual"] - ar["forecast_ar"]) ** 2)))

        for model, model_data in horizon_data.groupby("model"):
            error = model_data["actual"] - model_data["forecast"]
            rmse = float(np.sqrt(np.mean(error**2)))
            metric_rows.append(
                {
                    "horizon": int(horizon), "model": model, "n": len(error),
                    "first_origin": model_data["origin_date"].min(),
                    "last_origin": model_data["origin_date"].max(),
                    "rmse": rmse, "mae": float(np.mean(np.abs(error))),
                    "bias": float(np.mean(error)),
                    "relative_rmse_vs_ar": rmse / ar_rmse,
                }
            )

            if model != "ar":
                matched = model_data[
                    ["origin_date", "actual", "forecast"]
                ].merge(ar, on="origin_date", suffixes=("_model", "_ar"))
                dm, p_value, loss_diff = harvey_dm_test(
                    matched["actual_model"].to_numpy(),
                    matched["forecast"].to_numpy(),
                    matched["forecast_ar"].to_numpy(),
                    int(horizon),
                )
                dm_rows.append(
                    {
                        "horizon": int(horizon), "model": model,
                        "benchmark": "ar", "n": len(matched),
                        "dm_harvey": dm, "p_value": p_value,
                        "mean_loss_diff_ar_minus_model": loss_diff,
                    }
                )

        for regime, regime_data in horizon_data.groupby("calendar_regime"):
            ar_regime = regime_data.loc[
                regime_data["model"] == "ar", ["origin_date", "actual", "forecast"]
            ].rename(columns={"forecast": "forecast_ar"})
            if ar_regime.empty:
                continue
            ar_regime_rmse = float(
                np.sqrt(np.mean((ar_regime["actual"] - ar_regime["forecast_ar"]) ** 2))
            )
            for model, model_data in regime_data.groupby("model"):
                error = model_data["actual"] - model_data["forecast"]
                regime_rows.append(
                    {
                        "horizon": int(horizon), "calendar_regime": regime,
                        "model": model, "n": len(error),
                        "rmse": float(np.sqrt(np.mean(error**2))),
                        "mae": float(np.mean(np.abs(error))),
                        "relative_rmse_vs_ar": (
                            float(np.sqrt(np.mean(error**2))) / ar_regime_rmse
                        ),
                    }
                )

    metrics = pd.DataFrame(metric_rows).sort_values(["horizon", "rmse"])
    dm_tests = pd.DataFrame(dm_rows).sort_values(["horizon", "p_value"])
    regimes = pd.DataFrame(regime_rows).sort_values(
        ["horizon", "calendar_regime", "rmse"]
    )
    metrics.to_csv(output_dir / "metrics_all_models_with_bbim.csv", index=False)
    dm_tests.to_csv(output_dir / "dm_tests_vs_ar_with_bbim.csv", index=False)
    regimes.to_csv(output_dir / "metrics_regimes_with_bbim.csv", index=False)
    return metrics, dm_tests, regimes


# %% 11. Command-line entry point / 运行入口
def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=["smoke", "pilot", "paper"], default="smoke")
    parser.add_argument("--horizons", type=int, nargs="+", default=None)
    parser.add_argument("--oos-start", default=None)
    parser.add_argument("--information-lag", type=int, choices=[0, 1], default=0)
    parser.add_argument("--predictor-lags", type=int, default=3)
    parser.add_argument("--min-train", type=int, default=72)
    parser.add_argument("--rounds", type=int, default=None)
    parser.add_argument("--ensemble-size", type=int, default=None)
    parser.add_argument("--max-origins", type=int, default=None)
    parser.add_argument("--no-monotone", action="store_true")
    parser.add_argument("--benchmark-predictions", type=Path, default=None)
    parser.add_argument("--output-dir", type=Path, default=None)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    config = make_config(args)
    project_root = Path(__file__).resolve().parents[1]
    start_tag = pd.Timestamp(config.oos_start).strftime("%Y%m")
    constraint_tag = "mono" if config.use_monotone_constraints else "free"
    output_tag = (
        f"{config.mode}_{start_tag}_r{config.n_rounds}_e{config.ensemble_size}_"
        f"ilag{config.information_lag}_plags{config.predictor_lags}_{constraint_tag}"
    )
    output_dir = (
        args.output_dir.resolve()
        if args.output_dir is not None
        else project_root / "outputs" / "bbim_ukmd" / output_tag
    )
    output_dir.mkdir(parents=True, exist_ok=True)

    (output_dir / "run_config.json").write_text(
        json.dumps(asdict(config), indent=2), encoding="utf-8"
    )
    benchmark_path = (
        args.benchmark_predictions.resolve()
        if args.benchmark_predictions is not None
        else project_root / "outputs" / "full_with_random_forest" / "predictions.csv"
    )
    (output_dir / "run_metadata.json").write_text(
        json.dumps(
            {
                **asdict(config),
                "models": ["ar", "bbim_ukmd"],
                "benchmark_predictions": str(benchmark_path),
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    data, predictor_cols = load_ukmd(project_root, config.horizons)
    base_blocks = make_ukmd_blocks(predictor_cols)
    save_block_audit(base_blocks, output_dir)
    features, lagged_blocks = make_lagged_features(
        data,
        base_blocks,
        information_lag=config.information_lag,
        predictor_lags=config.predictor_lags,
    )
    monotone_signs = make_monotone_signs(lagged_blocks)

    print(json.dumps(asdict(config), indent=2))
    print("Base predictors:", len(predictor_cols))
    print("Lagged features:", features.shape[1])
    print("Block sizes:", {k: len(v) for k, v in base_blocks.items()})

    started = time.perf_counter()
    for horizon in config.horizons:
        checkpoint = output_dir / f"bbim_predictions_h{horizon}.csv"
        run_one_horizon(
            data=data,
            features=features,
            lagged_blocks=lagged_blocks,
            monotone_signs=monotone_signs,
            horizon=horizon,
            config=config,
            checkpoint_path=checkpoint,
        )

    # Collect every horizon already completed under the same specification.
    # This lets the user run h=1,3,6,12 in separate VS Code commands while the
    # summary tables grow automatically.
    prediction_files = sorted(output_dir.glob("bbim_predictions_h*.csv"))
    if not prediction_files:
        raise RuntimeError("No BBIM prediction files were produced.")
    bbim_predictions = pd.concat(
        [
            pd.read_csv(
                path,
                parse_dates=[
                    "origin_date", "target_date", "latest_train_origin_date",
                    "latest_train_target_date",
                ],
            )
            for path in prediction_files
        ],
        ignore_index=True,
    )
    bbim_predictions.to_csv(output_dir / "bbim_predictions_all.csv", index=False)
    metrics, dm_tests, regimes = evaluate_against_existing_models(
        bbim_predictions,
        project_root,
        output_dir,
        benchmark_predictions=benchmark_path,
    )

    if not metrics.empty:
        print("\nBBIM overall comparison / BBIM总体比较")
        print(
            metrics.loc[metrics["model"].isin(["ar", "bbim_ukmd"])]
            .to_string(index=False, float_format=lambda x: f"{x:.4f}")
        )
    if not dm_tests.empty:
        print("\nBBIM DM tests against AR / BBIM相对AR的DM检验")
        print(
            dm_tests.loc[dm_tests["model"] == "bbim_ukmd"]
            .to_string(index=False, float_format=lambda x: f"{x:.4f}")
        )
    print(f"\nOutputs: {output_dir}")
    print(f"Total runtime: {(time.perf_counter() - started) / 60:.2f} minutes")


if __name__ == "__main__":
    main()
