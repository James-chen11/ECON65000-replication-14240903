"""Consolidate the completed forecasting exercises into one audited result set.

This script does not estimate any forecasting model.  It reads the completed
baseline/Random-Forest, BBIM and neural-network pseudo-out-of-sample forecasts,
checks that their dates and realised targets agree, and creates the tables used
by the dissertation.

The output deliberately distinguishes the forecast-origin regime from the
target-date regime.  It also identifies forecasts whose entire origin-to-target
window stays within one of the four calendar regimes.  Four-regime h=12 results
are labelled descriptive because the post-2020 subperiods are short and the
forecast errors overlap heavily.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import platform
from datetime import datetime, timezone
from itertools import combinations
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd
import scipy
from scipy import stats


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_BASELINE = PROJECT_ROOT / "outputs" / "full_with_random_forest" / "predictions.csv"
DEFAULT_BBIM = (
    PROJECT_ROOT
    / "outputs"
    / "bbim_ukmd"
    / "paper_200801_r100_e10_ilag0_plags3_mono"
    / "bbim_predictions_all.csv"
)
DEFAULT_NN = (
    PROJECT_ROOT
    / "outputs"
    / "neural_network_ukmd"
    / "paper_200801_cv5_cvtrain72_v2_ilag0_plags4_s61351-61352-61353-61354-61355"
    / "nn_predictions_all.csv"
)
DEFAULT_OUTPUT = PROJECT_ROOT / "outputs" / "final_master"

KEY_COLUMNS = ["horizon", "origin_date", "target_date"]
CORE_COLUMNS = KEY_COLUMNS + ["model", "actual", "forecast"]
EXPECTED_MODELS = {
    "historical_mean",
    "naive",
    "ar",
    "factor_ar",
    "ridge",
    "lasso",
    "random_forest",
    "bbim_ukmd",
    "neural_network",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", type=Path, default=DEFAULT_BASELINE)
    parser.add_argument("--bbim", type=Path, default=DEFAULT_BBIM)
    parser.add_argument("--neural-network", type=Path, default=DEFAULT_NN)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)
    return parser.parse_args()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def calendar_regime(date: pd.Timestamp) -> str:
    """Four exogenous calendar periods used in the main regime description."""
    if date < pd.Timestamp("2020-01-01"):
        return "pre_covid"
    if date < pd.Timestamp("2022-01-01"):
        return "covid_2020_2021"
    if date < pd.Timestamp("2024-01-01"):
        return "high_inflation_2022_2023"
    return "disinflation_2024_plus"


def broad_period(date: pd.Timestamp) -> str:
    return "pre_2020" if date < pd.Timestamp("2020-01-01") else "2020_plus"


def read_source(path: Path, source: str) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(f"Missing {source} predictions: {path}")
    frame = pd.read_csv(path, parse_dates=["origin_date", "target_date"])
    missing = set(CORE_COLUMNS).difference(frame.columns)
    if missing:
        raise ValueError(f"{source} is missing required columns: {sorted(missing)}")
    frame = frame.copy()
    frame["source_file"] = source
    frame["horizon"] = frame["horizon"].astype(int)
    frame["actual"] = pd.to_numeric(frame["actual"], errors="raise")
    frame["forecast"] = pd.to_numeric(frame["forecast"], errors="raise")
    return frame


def audit_and_combine(
    baseline: pd.DataFrame,
    bbim: pd.DataFrame,
    neural_network: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    frames = [baseline, bbim, neural_network]
    audit_rows: list[dict[str, object]] = []
    for frame in frames:
        source = str(frame["source_file"].iloc[0])
        duplicate_count = int(frame.duplicated(KEY_COLUMNS + ["model"]).sum())
        audit_rows.append(
            {
                "check": "duplicate_model_keys",
                "source": source,
                "value": duplicate_count,
                "passed": duplicate_count == 0,
                "detail": "Duplicate horizon-origin-target-model rows must be zero.",
            }
        )
        if duplicate_count:
            raise ValueError(f"{source} contains {duplicate_count} duplicate forecast rows")

    combined = pd.concat(frames, ignore_index=True, sort=False)
    found_models = set(combined["model"].unique())
    audit_rows.append(
        {
            "check": "expected_model_set",
            "source": "combined",
            "value": len(found_models),
            "passed": found_models == EXPECTED_MODELS,
            "detail": f"Found={sorted(found_models)}; expected={sorted(EXPECTED_MODELS)}",
        }
    )
    if found_models != EXPECTED_MODELS:
        raise ValueError(
            f"Unexpected model set. Missing={sorted(EXPECTED_MODELS-found_models)}, "
            f"extra={sorted(found_models-EXPECTED_MODELS)}"
        )

    # Every model must use the same realised target at a given origin/horizon.
    target_check = combined.groupby(KEY_COLUMNS, sort=True).agg(
        n_models=("model", "nunique"),
        actual_min=("actual", "min"),
        actual_max=("actual", "max"),
    )
    target_check["actual_range"] = target_check["actual_max"] - target_check["actual_min"]
    unbalanced = int((target_check["n_models"] != len(EXPECTED_MODELS)).sum())
    actual_mismatch = int((target_check["actual_range"].abs() > 1e-10).sum())
    audit_rows.extend(
        [
            {
                "check": "balanced_model_coverage",
                "source": "combined",
                "value": unbalanced,
                "passed": unbalanced == 0,
                "detail": "Forecast keys without all nine models must be zero.",
            },
            {
                "check": "realised_target_agreement",
                "source": "combined",
                "value": actual_mismatch,
                "passed": actual_mismatch == 0,
                "detail": "Keys with different actual values across models must be zero.",
            },
        ]
    )
    if unbalanced or actual_mismatch:
        raise ValueError(
            f"Result alignment failed: unbalanced keys={unbalanced}, "
            f"actual-value mismatches={actual_mismatch}"
        )

    expected_target = pd.Series(
        [
            origin + pd.DateOffset(months=int(horizon))
            for origin, horizon in zip(combined["origin_date"], combined["horizon"])
        ],
        index=combined.index,
    )
    invalid_target_dates = int((expected_target != combined["target_date"]).sum())
    audit_rows.append(
        {
            "check": "target_date_equals_origin_plus_horizon",
            "source": "combined",
            "value": invalid_target_dates,
            "passed": invalid_target_dates == 0,
            "detail": "Rows with inconsistent target dates must be zero.",
        }
    )
    if invalid_target_dates:
        raise ValueError(f"Found {invalid_target_dates} inconsistent target dates")

    reported_error = pd.to_numeric(combined.get("error"), errors="coerce")
    recomputed_error = combined["actual"] - combined["forecast"]
    error_mismatches = int(
        ((reported_error - recomputed_error).abs() > 1e-8).fillna(False).sum()
    )
    combined["error"] = recomputed_error
    audit_rows.append(
        {
            "check": "reported_error_agreement",
            "source": "combined",
            "value": error_mismatches,
            "passed": error_mismatches == 0,
            "detail": "The master file always recomputes error as actual minus forecast.",
        }
    )

    # Carry target-based inflation states from the completed baseline pipeline.
    if "inflation_state" in baseline.columns:
        states = baseline[KEY_COLUMNS + ["inflation_state"]].drop_duplicates(KEY_COLUMNS)
        combined = combined.drop(columns=["inflation_state"], errors="ignore").merge(
            states, on=KEY_COLUMNS, how="left", validate="many_to_one"
        )

    combined["origin_regime"] = combined["origin_date"].map(calendar_regime)
    combined["target_regime"] = combined["target_date"].map(calendar_regime)
    combined["same_regime_window"] = combined["origin_regime"].eq(
        combined["target_regime"]
    )
    combined["origin_broad_period"] = combined["origin_date"].map(broad_period)
    combined["target_broad_period"] = combined["target_date"].map(broad_period)
    combined["absolute_error"] = combined["error"].abs()
    combined["squared_error"] = combined["error"].pow(2)
    combined = combined.sort_values(KEY_COLUMNS + ["model"]).reset_index(drop=True)
    return combined, pd.DataFrame(audit_rows)


def metric_table(
    frame: pd.DataFrame,
    group_columns: list[str],
) -> pd.DataFrame:
    metrics = (
        frame.groupby(group_columns + ["model"], sort=True, dropna=False)
        .agg(
            n=("error", "size"),
            first_origin=("origin_date", "min"),
            last_origin=("origin_date", "max"),
            rmse=("squared_error", lambda x: float(np.sqrt(x.mean()))),
            mae=("absolute_error", "mean"),
            bias=("error", "mean"),
        )
        .reset_index()
    )
    ar = metrics.loc[metrics["model"].eq("ar"), group_columns + ["rmse", "mae"]].rename(
        columns={"rmse": "ar_rmse", "mae": "ar_mae"}
    )
    metrics = metrics.merge(ar, on=group_columns, how="left", validate="many_to_one")
    metrics["relative_rmse_vs_ar"] = metrics["rmse"] / metrics["ar_rmse"]
    metrics["relative_mae_vs_ar"] = metrics["mae"] / metrics["ar_mae"]
    return metrics.sort_values(group_columns + ["rmse", "model"]).reset_index(drop=True)


def make_regime_metrics(frame: pd.DataFrame) -> pd.DataFrame:
    definitions: list[tuple[str, str, pd.DataFrame]] = [
        ("origin_calendar", "origin_regime", frame),
        ("target_calendar", "target_regime", frame),
        (
            "same_calendar_window",
            "target_regime",
            frame.loc[frame["same_regime_window"]].copy(),
        ),
        ("target_broad_period", "target_broad_period", frame),
    ]
    tables: list[pd.DataFrame] = []
    for basis, regime_column, subset in definitions:
        table = metric_table(subset, ["horizon", regime_column]).rename(
            columns={regime_column: "regime"}
        )
        table.insert(1, "regime_basis", basis)
        # Effective non-overlapping observations are an intentionally conservative
        # diagnostic; it is not used to rescale the reported RMSE or MAE.
        table["approx_nonoverlap_n"] = np.ceil(table["n"] / table["horizon"]).astype(int)
        table["analysis_role"] = np.where(
            (table["regime_basis"] != "target_broad_period")
            & (table["horizon"] == 12),
            "descriptive_appendix",
            np.where(table["n"] < 24, "descriptive_small_sample", "main_descriptive"),
        )
        tables.append(table)
    return pd.concat(tables, ignore_index=True).sort_values(
        ["regime_basis", "horizon", "regime", "rmse"]
    )


def dm_harvey(
    errors_a: np.ndarray,
    errors_b: np.ndarray,
    horizon: int,
) -> tuple[float, float, float, int]:
    """Squared-error DM test; negative loss difference favours model A."""
    valid = np.isfinite(errors_a) & np.isfinite(errors_b)
    differential = errors_a[valid] ** 2 - errors_b[valid] ** 2
    n = len(differential)
    if n < max(8, horizon + 3):
        mean = float(np.mean(differential)) if n else np.nan
        return np.nan, np.nan, mean, n
    centered = differential - differential.mean()
    max_lag = min(horizon - 1, n - 2)
    long_run_variance = float(np.dot(centered, centered) / n)
    for lag in range(1, max_lag + 1):
        covariance = float(np.dot(centered[lag:], centered[:-lag]) / n)
        bartlett_weight = 1.0 - lag / (max_lag + 1.0)
        long_run_variance += 2.0 * bartlett_weight * covariance
    if not np.isfinite(long_run_variance) or long_run_variance <= 0:
        return np.nan, np.nan, float(differential.mean()), n
    statistic = float(differential.mean() / np.sqrt(long_run_variance / n))
    harvey_term = (n + 1 - 2 * horizon + horizon * (horizon - 1) / n) / n
    if harvey_term <= 0:
        return np.nan, np.nan, float(differential.mean()), n
    statistic *= math.sqrt(harvey_term)
    p_value = float(2.0 * stats.t.sf(abs(statistic), df=n - 1))
    return statistic, p_value, float(differential.mean()), n


def holm_adjust(p_values: Iterable[float]) -> np.ndarray:
    values = np.asarray(list(p_values), dtype=float)
    adjusted = np.full(len(values), np.nan)
    valid_positions = np.flatnonzero(np.isfinite(values))
    if not len(valid_positions):
        return adjusted
    order = valid_positions[np.argsort(values[valid_positions])]
    running_max = 0.0
    total = len(order)
    for rank, position in enumerate(order):
        candidate = min(1.0, (total - rank) * values[position])
        running_max = max(running_max, candidate)
        adjusted[position] = running_max
    return adjusted


def paired_dm_rows(
    frame: pd.DataFrame,
    pairs: Iterable[tuple[str, str]],
    extra: dict[str, object] | None = None,
) -> list[dict[str, object]]:
    extra = extra or {}
    rows: list[dict[str, object]] = []
    for model_a, model_b in pairs:
        a = frame.loc[frame["model"].eq(model_a), ["origin_date", "error"]].rename(
            columns={"error": "error_a"}
        )
        b = frame.loc[frame["model"].eq(model_b), ["origin_date", "error"]].rename(
            columns={"error": "error_b"}
        )
        matched = a.merge(b, on="origin_date", how="inner", validate="one_to_one")
        horizon = int(frame["horizon"].iloc[0])
        statistic, p_value, mean_diff, n = dm_harvey(
            matched["error_a"].to_numpy(),
            matched["error_b"].to_numpy(),
            horizon,
        )
        rows.append(
            {
                **extra,
                "horizon": horizon,
                "model_a": model_a,
                "model_b": model_b,
                "n": n,
                "dm_harvey": statistic,
                "p_value_raw": p_value,
                "mean_loss_diff_a_minus_b": mean_diff,
                "favoured_by_squared_loss": (
                    model_a if mean_diff < 0 else model_b if mean_diff > 0 else "tie"
                ),
            }
        )
    return rows


def make_dm_tables(frame: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    models = sorted(frame["model"].unique())
    all_rows: list[dict[str, object]] = []
    ar_rows: list[dict[str, object]] = []
    for horizon, subset in frame.groupby("horizon", sort=True):
        all_rows.extend(paired_dm_rows(subset, combinations(models, 2)))
        ar_pairs = [(model, "ar") for model in models if model != "ar"]
        ar_rows.extend(paired_dm_rows(subset, ar_pairs))
    all_dm = pd.DataFrame(all_rows)
    versus_ar = pd.DataFrame(ar_rows)
    for table in (all_dm, versus_ar):
        table["p_value_holm_within_horizon"] = table.groupby("horizon")[
            "p_value_raw"
        ].transform(holm_adjust)
        table["significant_raw_5pct"] = table["p_value_raw"] < 0.05
        table["significant_holm_5pct"] = table["p_value_holm_within_horizon"] < 0.05

    # Exploratory regime tests against AR.  These are retained for transparency,
    # but short four-regime h=12 tests must not be presented as primary evidence.
    regime_rows: list[dict[str, object]] = []
    for basis, regime_column, source in [
        ("origin_calendar", "origin_regime", frame),
        ("target_calendar", "target_regime", frame),
        ("same_calendar_window", "target_regime", frame.loc[frame["same_regime_window"]]),
        ("target_broad_period", "target_broad_period", frame),
    ]:
        for (horizon, regime), subset in source.groupby(["horizon", regime_column]):
            pairs = [(model, "ar") for model in models if model != "ar"]
            regime_rows.extend(
                paired_dm_rows(
                    subset,
                    pairs,
                    extra={"regime_basis": basis, "regime": regime},
                )
            )
    regime_dm = pd.DataFrame(regime_rows)
    correction_keys = ["regime_basis", "horizon", "regime"]
    regime_dm["p_value_holm_within_regime"] = regime_dm.groupby(correction_keys)[
        "p_value_raw"
    ].transform(holm_adjust)
    regime_dm["analysis_role"] = np.where(
        (regime_dm["regime_basis"] != "target_broad_period")
        & (regime_dm["horizon"] == 12),
        "exploratory_appendix",
        np.where(regime_dm["n"] < 24, "exploratory_small_sample", "exploratory"),
    )
    return all_dm, versus_ar, regime_dm


def cross_horizon_table(metrics: pd.DataFrame, horizons: list[int]) -> pd.DataFrame:
    subset = metrics.loc[metrics["horizon"].isin(horizons)].copy()
    result = (
        subset.groupby("model", as_index=False)
        .agg(
            number_of_horizons=("horizon", "nunique"),
            average_relative_rmse=("relative_rmse_vs_ar", "mean"),
            average_relative_mae=("relative_mae_vs_ar", "mean"),
        )
        .sort_values(["average_relative_rmse", "model"])
        .reset_index(drop=True)
    )
    result.insert(0, "rank", np.arange(1, len(result) + 1))
    result.insert(1, "included_horizons", "/".join(map(str, horizons)))
    return result


def winner_runner_up_dm(
    predictions: pd.DataFrame,
    metrics: pd.DataFrame,
) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for horizon, ranked in metrics.groupby("horizon", sort=True):
        ranked = ranked.sort_values("rmse")
        winner, runner_up = ranked.iloc[0]["model"], ranked.iloc[1]["model"]
        subset = predictions.loc[predictions["horizon"].eq(horizon)]
        row = paired_dm_rows(subset, [(winner, runner_up)])[0]
        row["winner_rmse"] = float(ranked.iloc[0]["rmse"])
        row["runner_up_rmse"] = float(ranked.iloc[1]["rmse"])
        rows.append(row)
    result = pd.DataFrame(rows)
    result["p_value_holm_across_horizons"] = holm_adjust(result["p_value_raw"])
    result["analysis_role"] = "post_selection_exploratory"
    return result


def main() -> None:
    args = parse_args()
    sources = {
        "baseline_random_forest": args.baseline.resolve(),
        "bbim_ukmd": args.bbim.resolve(),
        "neural_network": args.neural_network.resolve(),
    }
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    baseline = read_source(sources["baseline_random_forest"], "baseline_random_forest")
    bbim = read_source(sources["bbim_ukmd"], "bbim_ukmd")
    neural_network = read_source(sources["neural_network"], "neural_network")
    predictions, audit = audit_and_combine(baseline, bbim, neural_network)

    metrics = metric_table(predictions, ["horizon"])
    regimes = make_regime_metrics(predictions)
    dm_pairwise, dm_vs_ar, dm_regimes = make_dm_tables(predictions)
    main_table = metrics.merge(
        dm_vs_ar[
            [
                "horizon", "model_a", "dm_harvey", "p_value_raw",
                "p_value_holm_within_horizon", "significant_raw_5pct",
                "significant_holm_5pct",
            ]
        ],
        left_on=["horizon", "model"],
        right_on=["horizon", "model_a"],
        how="left",
    ).drop(columns="model_a")
    main_table["comparison_note"] = np.where(
        main_table["model"].eq("ar"), "benchmark", "candidate versus AR"
    )
    winner_dm = winner_runner_up_dm(predictions, metrics)
    cross_all = cross_horizon_table(metrics, [1, 3, 6, 12])
    cross_joseph = cross_horizon_table(metrics, [3, 6, 12])

    # Starting the evaluation in 2018 does not require re-estimation under an
    # expanding window: the saved 2018+ forecasts were already trained on all
    # information available since 1998.  We nevertheless recompute every metric
    # and DM test on this shorter, matched evaluation sample.
    oos2018 = predictions.loc[predictions["origin_date"] >= pd.Timestamp("2018-01-01")]
    metrics_oos2018 = metric_table(oos2018, ["horizon"])
    dm_pairwise_oos2018, dm_vs_ar_oos2018, _ = make_dm_tables(oos2018)

    predictions.to_csv(output_dir / "all_model_predictions.csv", index=False)
    metrics.to_csv(output_dir / "all_model_metrics.csv", index=False)
    main_table.to_csv(output_dir / "main_results_with_dm.csv", index=False)
    winner_dm.to_csv(output_dir / "winner_vs_runner_up_dm.csv", index=False)
    cross_all.to_csv(output_dir / "cross_horizon_average_1_3_6_12.csv", index=False)
    cross_joseph.to_csv(output_dir / "joseph_average_3_6_12.csv", index=False)
    regimes.to_csv(output_dir / "all_model_regime_metrics.csv", index=False)
    dm_pairwise.to_csv(output_dir / "all_model_dm_pairwise.csv", index=False)
    dm_vs_ar.to_csv(output_dir / "all_model_dm_vs_ar.csv", index=False)
    dm_regimes.to_csv(output_dir / "all_model_regime_dm_exploratory.csv", index=False)
    metrics_oos2018.to_csv(output_dir / "robustness_oos2018_metrics.csv", index=False)
    dm_vs_ar_oos2018.to_csv(output_dir / "robustness_oos2018_dm_vs_ar.csv", index=False)
    dm_pairwise_oos2018.to_csv(
        output_dir / "robustness_oos2018_dm_pairwise.csv", index=False
    )
    audit.to_csv(output_dir / "data_alignment_audit.csv", index=False)

    manifest = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "script": str(Path(__file__).resolve()),
        "python": platform.python_version(),
        "pandas": pd.__version__,
        "numpy": np.__version__,
        "scipy": scipy.__version__,
        "sources": {
            name: {"path": str(path), "sha256": sha256(path)}
            for name, path in sources.items()
        },
        "rows": int(len(predictions)),
        "forecast_keys": int(predictions[KEY_COLUMNS].drop_duplicates().shape[0]),
        "models": sorted(predictions["model"].unique().tolist()),
        "horizons": sorted(int(x) for x in predictions["horizon"].unique()),
        "all_audits_passed": bool(audit["passed"].all()),
        "definitions": {
            "error": "actual minus forecast",
            "dm_loss": "squared forecast error",
            "dm_hac_lags": "horizon minus one with Bartlett weights",
            "dm_p_value": "two-sided Harvey small-sample adjusted",
            "holm_scope": "within each horizon (or horizon-regime cell)",
            "primary_regime": "target-date calendar regime",
        },
    }
    (output_dir / "run_manifest.json").write_text(
        json.dumps(manifest, indent=2), encoding="utf-8"
    )

    winners = metrics.loc[metrics.groupby("horizon")["rmse"].idxmin(), [
        "horizon", "model", "rmse", "mae", "relative_rmse_vs_ar"
    ]]
    print(f"Saved consolidated results to: {output_dir}")
    print(f"Rows={len(predictions):,}; models={predictions['model'].nunique()}; "
          f"forecast keys={predictions[KEY_COLUMNS].drop_duplicates().shape[0]:,}")
    print(f"All alignment audits passed: {audit['passed'].all()}")
    print("\nLowest RMSE by horizon:")
    print(winners.to_string(index=False, float_format=lambda x: f"{x:.4f}"))


if __name__ == "__main__":
    main()
