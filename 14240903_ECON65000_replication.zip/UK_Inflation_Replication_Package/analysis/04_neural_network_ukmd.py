r"""Small neural-network extension for the UK inflation dissertation.

This script estimates a shallow multilayer perceptron (MLP) using exactly the
same direct targets, March-2026 UK-MD panel, expanding-window information rule,
and 2008 pseudo-out-of-sample start as the main dissertation pipeline.

The implementation is deliberately small because the monthly sample contains
only a few hundred observations. Hyperparameters are selected using
TimeSeriesSplit with an h-month gap; random K-fold validation is never used.
All imputation and scaling are fitted inside each training window.

VS Code commands (run from the project root)
------------------------------------------------
Quick code check / 快速检查:
    .\.venv\Scripts\python.exe analysis\04_neural_network_ukmd.py --mode smoke

Recommended pilot / 建议先跑12个月pilot:
    .\.venv\Scripts\python.exe analysis\04_neural_network_ukmd.py --mode pilot --horizons 12

Formal horizons, one at a time / 正式结果建议逐个期限运行:
    .\.venv\Scripts\python.exe analysis\04_neural_network_ukmd.py --mode paper --horizons 1
    .\.venv\Scripts\python.exe analysis\04_neural_network_ukmd.py --mode paper --horizons 3
    .\.venv\Scripts\python.exe analysis\04_neural_network_ukmd.py --mode paper --horizons 6
    .\.venv\Scripts\python.exe analysis\04_neural_network_ukmd.py --mode paper --horizons 12

Faster single-seed diagnostic (not the primary specification):
    .\.venv\Scripts\python.exe analysis\04_neural_network_ukmd.py --mode paper --horizons 6 --seeds 61351
"""

# %% 1. Imports / 导入
from __future__ import annotations

import argparse
import json
import math
import time
import warnings
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import sklearn
from scipy import stats
from sklearn.base import clone
from sklearn.exceptions import ConvergenceWarning
from sklearn.impute import SimpleImputer
from sklearn.model_selection import GridSearchCV, TimeSeriesSplit
from sklearn.neural_network import MLPRegressor
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler


RANDOM_SEED = 61351


# %% 2. Configuration / 配置
@dataclass(frozen=True)
class RunConfig:
    mode: str
    horizons: tuple[int, ...]
    oos_start: str
    information_lag: int
    predictor_lags: int
    min_train: int
    cv_splits: int
    max_iter: int
    hidden_layers: tuple[tuple[int, ...], ...]
    alphas: tuple[float, ...]
    learning_rates: tuple[float, ...]
    seeds: tuple[int, ...]
    max_origins: int | None


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=["smoke", "pilot", "paper"], default="smoke")
    parser.add_argument("--horizons", type=int, nargs="+", default=None)
    parser.add_argument("--oos-start", default=None)
    parser.add_argument("--information-lag", type=int, choices=[0, 1], default=0)
    parser.add_argument("--predictor-lags", type=int, default=4)
    parser.add_argument("--min-train", type=int, default=72)
    parser.add_argument("--cv-splits", type=int, default=None)
    parser.add_argument("--max-iter", type=int, default=None)
    parser.add_argument("--max-origins", type=int, default=None)
    parser.add_argument("--seeds", type=int, nargs="+", default=None)
    parser.add_argument("--benchmark-predictions", type=Path, default=None)
    parser.add_argument("--output-dir", type=Path, default=None)
    return parser.parse_args()


def make_config(args: argparse.Namespace) -> RunConfig:
    if args.mode == "smoke":
        defaults = {
            "horizons": (12,),
            "oos_start": "2024-01-01",
            "cv_splits": 2,
            "max_iter": 300,
            "hidden_layers": ((16,),),
            "alphas": (0.01,),
            "learning_rates": (0.001,),
            "seeds": (RANDOM_SEED,),
            "max_origins": 3,
        }
    elif args.mode == "pilot":
        defaults = {
            "horizons": (12,),
            "oos_start": "2020-01-01",
            "cv_splits": 3,
            "max_iter": 1_000,
            "hidden_layers": ((16,), (32,)),
            "alphas": (0.001, 0.01),
            "learning_rates": (0.001,),
            "seeds": (RANDOM_SEED, RANDOM_SEED + 1, RANDOM_SEED + 2),
            "max_origins": None,
        }
    else:
        defaults = {
            "horizons": (1, 3, 6, 12),
            "oos_start": "2008-01-01",
            "cv_splits": 5,
            "max_iter": 500,
            # Depth search fixed before the formal NN run:
            # (32,16) follows Goulet Coulombe et al.; (32,16,8) follows
            # the Deep-NN robustness model in Medeiros et al.  The one-layer
            # network is retained as the transparent shallow benchmark.
            "hidden_layers": ((32,), (32, 16), (32, 16, 8)),
            "alphas": (0.0001, 0.001, 0.01, 0.1),
            "learning_rates": (0.001, 0.01),
            # Five initialisations follow the macro-NN ensemble convention.
            "seeds": tuple(RANDOM_SEED + i for i in range(5)),
            "max_origins": None,
        }

    horizons = tuple(args.horizons or defaults["horizons"])
    if any(h not in {1, 3, 6, 12, 24} for h in horizons):
        raise ValueError("Supported horizons are 1, 3, 6, 12 and optional 24.")

    return RunConfig(
        mode=args.mode,
        horizons=horizons,
        oos_start=args.oos_start or defaults["oos_start"],
        information_lag=args.information_lag,
        predictor_lags=args.predictor_lags,
        min_train=args.min_train,
        cv_splits=args.cv_splits or defaults["cv_splits"],
        max_iter=args.max_iter or defaults["max_iter"],
        hidden_layers=defaults["hidden_layers"],
        alphas=defaults["alphas"],
        learning_rates=defaults["learning_rates"],
        seeds=tuple(args.seeds or defaults["seeds"]),
        max_origins=(
            args.max_origins
            if args.max_origins is not None
            else defaults["max_origins"]
        ),
    )


# %% 3. Data and direct forecast targets / 数据与直接多步目标
def load_ukmd(
    project_root: Path,
    horizons: tuple[int, ...],
) -> tuple[pd.DataFrame, list[str]]:
    data_dir = project_root / "data" / "UKMD_March_2026"
    raw = pd.read_csv(data_dir / "raw_uk_md.csv")
    balanced = pd.read_csv(data_dir / "balanced_uk_md.csv")

    for frame in (raw, balanced):
        frame.drop(columns=["Unnamed: 0"], errors="ignore", inplace=True)

    raw = raw.loc[raw["Date"].astype(str) != "Transform"].copy()
    raw["Date"] = pd.to_datetime(raw["Date"], errors="raise")
    balanced["Date"] = pd.to_datetime(balanced["Date"], errors="raise")
    raw.sort_values("Date", inplace=True)
    balanced.sort_values("Date", inplace=True)
    raw.reset_index(drop=True, inplace=True)
    balanced.reset_index(drop=True, inplace=True)

    predictor_cols = [c for c in balanced.columns if c != "Date"]
    balanced[predictor_cols] = balanced[predictor_cols].apply(
        pd.to_numeric, errors="coerce"
    )
    balanced.replace([np.inf, -np.inf], np.nan, inplace=True)
    raw["CPI_ALL"] = pd.to_numeric(raw["CPI_ALL"], errors="coerce")

    monthly_steps = balanced["Date"].dt.to_period("M").astype(int).diff().dropna()
    if not (monthly_steps == 1).all():
        raise ValueError("balanced_uk_md.csv is not monthly-contiguous.")

    cpi = raw[["Date", "CPI_ALL"]].dropna().copy()
    cpi.rename(columns={"CPI_ALL": "CPI_ALL_INDEX"}, inplace=True)
    log_cpi = np.log(cpi["CPI_ALL_INDEX"])
    cpi["infl_mom_ann"] = 1200.0 * log_cpi.diff(1)
    cpi["infl_yoy"] = 100.0 * log_cpi.diff(12)
    for horizon in horizons:
        cpi[f"target_h{horizon}"] = (1200.0 / horizon) * (
            log_cpi.shift(-horizon) - log_cpi
        )

    data = balanced.merge(cpi, on="Date", how="left", validate="one_to_one")
    data.replace([np.inf, -np.inf], np.nan, inplace=True)
    return data.reset_index(drop=True), predictor_cols


def build_panel_features(
    data: pd.DataFrame,
    predictor_cols: list[str],
    predictor_lags: int,
    information_lag: int,
) -> pd.DataFrame:
    """Match the main pipeline: all UK-MD variables plus two inflation measures."""
    base = predictor_cols + ["infl_mom_ann", "infl_yoy"]
    parts: list[pd.DataFrame] = []
    for lag in range(information_lag, information_lag + predictor_lags):
        shifted = data[base].shift(lag)
        shifted.columns = [f"{column}_lag{lag}" for column in base]
        parts.append(shifted)
    return pd.concat(parts, axis=1)


# %% 4. Small MLP specification / 小型MLP设定
def make_mlp(seed: int, max_iter: int) -> Pipeline:
    """Imputation and scaling are estimated only inside each training window."""
    return Pipeline(
        [
            (
                "imputer",
                SimpleImputer(strategy="median", keep_empty_features=True),
            ),
            ("scale", StandardScaler()),
            (
                "model",
                MLPRegressor(
                    activation="relu",
                    solver="adam",
                    batch_size=32,
                    max_iter=max_iter,
                    shuffle=False,
                    early_stopping=False,
                    tol=1e-4,
                    n_iter_no_change=20,
                    random_state=seed,
                ),
            ),
        ]
    )


def parameter_grid(config: RunConfig) -> dict[str, list[Any]]:
    return {
        "model__hidden_layer_sizes": list(config.hidden_layers),
        "model__alpha": list(config.alphas),
        "model__learning_rate_init": list(config.learning_rates),
    }


def tune_parameters(
    x_train: pd.DataFrame,
    y_train: pd.Series,
    horizon: int,
    config: RunConfig,
) -> dict[str, Any]:
    """Annual tuning using ordered validation folds and an h-month gap."""
    gap = min(horizon, max(0, len(y_train) // 8))
    # sklearn's default test size can leave only a handful of observations in
    # the earliest training fold when h is large.  Reserve at least MIN_TRAIN
    # observations for every CV training fold, while using validation blocks
    # of no more than twelve months.
    available_after_minimum = len(y_train) - gap - config.min_train
    if available_after_minimum < config.cv_splits:
        raise ValueError(
            "Not enough observations for leakage-safe time-series CV: "
            f"n={len(y_train)}, gap={gap}, min_train={config.min_train}, "
            f"splits={config.cv_splits}."
        )
    test_size = max(
        1,
        min(12, available_after_minimum // config.cv_splits),
    )
    splitter = TimeSeriesSplit(
        n_splits=config.cv_splits,
        gap=gap,
        test_size=test_size,
    )
    search = GridSearchCV(
        make_mlp(config.seeds[0], config.max_iter),
        parameter_grid(config),
        cv=splitter,
        scoring="neg_root_mean_squared_error",
        n_jobs=1,
        refit=False,
        error_score="raise",
    )
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=ConvergenceWarning)
        warnings.filterwarnings(
            "ignore",
            message=r"Got `batch_size` less than 1 or larger than sample size.*",
            category=UserWarning,
        )
        search.fit(x_train, y_train)
    return dict(search.best_params_)


def json_ready_params(params: dict[str, Any]) -> dict[str, Any]:
    ready = dict(params)
    if isinstance(ready.get("model__hidden_layer_sizes"), tuple):
        ready["model__hidden_layer_sizes"] = list(
            ready["model__hidden_layer_sizes"]
        )
    return ready


def sklearn_ready_params(params: dict[str, Any]) -> dict[str, Any]:
    ready = dict(params)
    if isinstance(ready.get("model__hidden_layer_sizes"), list):
        ready["model__hidden_layer_sizes"] = tuple(
            ready["model__hidden_layer_sizes"]
        )
    return ready


def load_tuning_cache(path: Path) -> dict[str, dict[str, Any]]:
    if not path.exists():
        return {}
    raw = json.loads(path.read_text(encoding="utf-8"))
    return {key: sklearn_ready_params(value) for key, value in raw.items()}


def save_tuning_cache(path: Path, cache: dict[str, dict[str, Any]]) -> None:
    payload = {key: json_ready_params(value) for key, value in cache.items()}
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


# %% 5. Expanding-window pseudo-OOS forecasts / 扩展窗口伪样本外预测
def calendar_regime(date: pd.Timestamp) -> str:
    if date < pd.Timestamp("2020-01-01"):
        return "pre_covid"
    if date < pd.Timestamp("2022-01-01"):
        return "covid"
    if date < pd.Timestamp("2024-01-01"):
        return "high_inflation_episode"
    return "disinflation"


def run_one_horizon(
    data: pd.DataFrame,
    features: pd.DataFrame,
    horizon: int,
    config: RunConfig,
    checkpoint_path: Path,
    tuning_path: Path,
) -> pd.DataFrame:
    target = data[f"target_h{horizon}"]
    possible = list(
        data.index[
            (data["Date"] >= pd.Timestamp(config.oos_start)) & target.notna()
        ]
    )
    if config.max_origins is not None:
        possible = possible[-config.max_origins :]

    if checkpoint_path.exists():
        existing = pd.read_csv(checkpoint_path, parse_dates=["origin_date"])
        rows = existing.to_dict("records")
        completed = set(existing["origin_date"])
    else:
        rows = []
        completed = set()

    tuning_cache = load_tuning_cache(tuning_path)
    new_origin_times: list[float] = []

    for number, origin_idx in enumerate(possible, start=1):
        origin_date = pd.Timestamp(data.at[origin_idx, "Date"])
        if origin_date in completed:
            continue

        # The target starting at s is known at origin t only if s+h <= t.
        latest_train_idx = origin_idx - horizon
        train_idx = target.index[
            (target.index <= latest_train_idx) & target.notna()
        ]
        if len(train_idx) < config.min_train:
            continue

        x_train = features.loc[train_idx]
        y_train = target.loc[train_idx]
        x_test = features.loc[[origin_idx]]
        cache_key = f"h{horizon}_{origin_date.year}"
        started = time.perf_counter()

        if cache_key not in tuning_cache:
            params = tune_parameters(x_train, y_train, horizon, config)
            tuning_cache[cache_key] = params
            save_tuning_cache(tuning_path, tuning_cache)
            tuned_now = True
        else:
            params = tuning_cache[cache_key]
            tuned_now = False

        seed_forecasts: list[float] = []
        iteration_counts: list[int] = []
        for seed in config.seeds:
            estimator = clone(make_mlp(seed, config.max_iter)).set_params(**params)
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", category=ConvergenceWarning)
                warnings.filterwarnings(
                    "ignore",
                    message=(
                        r"Got `batch_size` less than 1 or larger than sample size.*"
                    ),
                    category=UserWarning,
                )
                estimator.fit(x_train, y_train)
            seed_forecasts.append(float(estimator.predict(x_test)[0]))
            iteration_counts.append(int(estimator.named_steps["model"].n_iter_))

        forecast = float(np.mean(seed_forecasts))
        actual = float(target.loc[origin_idx])
        target_date = origin_date + pd.DateOffset(months=horizon)
        elapsed = time.perf_counter() - started
        new_origin_times.append(elapsed)

        rows.append(
            {
                "origin_date": origin_date,
                "target_date": target_date,
                "latest_train_origin_date": pd.Timestamp(
                    data.at[train_idx[-1], "Date"]
                ),
                "latest_train_target_date": pd.Timestamp(
                    data.at[train_idx[-1], "Date"]
                ) + pd.DateOffset(months=horizon),
                "horizon": horizon,
                "model": "neural_network",
                "actual": actual,
                "forecast": forecast,
                "error": actual - forecast,
                # Store both definitions; neither label is used for training.
                "origin_regime": calendar_regime(origin_date),
                "target_regime": calendar_regime(target_date),
                "same_regime_window": (
                    calendar_regime(origin_date) == calendar_regime(target_date)
                ),
                "n_train": len(train_idx),
                "n_seeds": len(config.seeds),
                "seeds": json.dumps(config.seeds),
                "best_params": json.dumps(json_ready_params(params), sort_keys=True),
                "mean_n_iter": float(np.mean(iteration_counts)),
                "tuned_now": tuned_now,
                "fit_seconds": elapsed,
            }
        )
        result = pd.DataFrame(rows).sort_values("origin_date").reset_index(drop=True)
        result.to_csv(checkpoint_path, index=False)

        recent = float(np.mean(new_origin_times[-12:]))
        remaining = sum(
            pd.Timestamp(data.at[idx, "Date"]) not in completed
            for idx in possible[number:]
        )
        print(
            f"h={horizon} {origin_date:%Y-%m}: train={len(train_idx)}, "
            f"tuned={'yes' if tuned_now else 'no'}, fit={elapsed:.1f}s, "
            f"recent average={recent:.1f}s/origin, "
            f"rough remaining={remaining * recent / 60:.1f}min",
            flush=True,
        )
        completed.add(origin_date)

    if not rows:
        raise RuntimeError(f"No neural-network forecasts were produced for h={horizon}.")
    return pd.DataFrame(rows).sort_values("origin_date").reset_index(drop=True)


# %% 6. Evaluation on exactly matched dates / 在完全相同日期上评价
def harvey_dm_test(
    actual: np.ndarray,
    forecast_model: np.ndarray,
    forecast_ar: np.ndarray,
    horizon: int,
) -> tuple[float, float, float]:
    """Positive loss difference means the neural network beats AR."""
    e_model = np.asarray(actual) - np.asarray(forecast_model)
    e_ar = np.asarray(actual) - np.asarray(forecast_ar)
    differential = e_ar**2 - e_model**2
    differential = differential[np.isfinite(differential)]
    n = len(differential)
    if n < max(8, horizon + 3):
        return np.nan, np.nan, float(np.mean(differential)) if n else np.nan

    centered = differential - differential.mean()
    max_lag = min(horizon - 1, n - 2)
    long_run_variance = float(np.dot(centered, centered) / n)
    for lag in range(1, max_lag + 1):
        covariance = float(np.dot(centered[lag:], centered[:-lag]) / n)
        weight = 1.0 - lag / (max_lag + 1.0)
        long_run_variance += 2.0 * weight * covariance
    if not np.isfinite(long_run_variance) or long_run_variance <= 0:
        return np.nan, np.nan, float(differential.mean())

    dm = float(differential.mean() / np.sqrt(long_run_variance / n))
    harvey_term = (n + 1 - 2 * horizon + horizon * (horizon - 1) / n) / n
    if harvey_term <= 0:
        return np.nan, np.nan, float(differential.mean())
    dm_harvey = dm * np.sqrt(harvey_term)
    p_value = float(2.0 * stats.t.sf(abs(dm_harvey), df=n - 1))
    return dm_harvey, p_value, float(differential.mean())


def evaluate(
    nn_predictions: pd.DataFrame,
    project_root: Path,
    output_dir: Path,
    benchmark_predictions: Path | None = None,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    baseline_path = benchmark_predictions or (
        project_root / "outputs" / "full_with_random_forest" / "predictions.csv"
    )
    if not baseline_path.exists():
        print("Baseline predictions not found; neural forecasts were still saved.")
        return pd.DataFrame(), pd.DataFrame()

    baseline = pd.read_csv(
        baseline_path,
        parse_dates=["origin_date", "target_date"],
    )
    keep = ["origin_date", "target_date", "horizon", "model", "actual", "forecast"]
    combined = pd.concat([baseline[keep], nn_predictions[keep]], ignore_index=True)
    # Keep both ex-post evaluation conventions. Regime labels are never inputs.
    combined["origin_regime"] = combined["origin_date"].map(calendar_regime)
    combined["target_regime"] = combined["target_date"].map(calendar_regime)
    combined["same_regime_window"] = (
        combined["origin_regime"] == combined["target_regime"]
    )
    combined.to_csv(output_dir / "predictions_all_models_with_nn.csv", index=False)

    # Standard output for the common robustness summariser. The benchmark AR
    # must be estimated under the same information-set specification as the NN.
    valid_keys = nn_predictions[["horizon", "origin_date"]].drop_duplicates()
    standard = combined.loc[
        combined["model"].isin(["ar", "neural_network"])
    ].merge(valid_keys, on=["horizon", "origin_date"], how="inner")
    standard["error"] = standard["actual"] - standard["forecast"]
    standard.to_csv(output_dir / "predictions.csv", index=False)

    metric_rows: list[dict[str, Any]] = []
    dm_rows: list[dict[str, Any]] = []
    for horizon, unbalanced in combined.groupby("horizon"):
        nn_dates = set(
            unbalanced.loc[
                unbalanced["model"] == "neural_network", "origin_date"
            ]
        )
        if not nn_dates:
            continue
        frame = unbalanced.loc[unbalanced["origin_date"].isin(nn_dates)].copy()
        ar = frame.loc[
            frame["model"] == "ar", ["origin_date", "actual", "forecast"]
        ].rename(columns={"forecast": "forecast_ar"})
        ar_rmse = float(np.sqrt(np.mean((ar["actual"] - ar["forecast_ar"]) ** 2)))

        for model, group in frame.groupby("model"):
            error = group["actual"] - group["forecast"]
            rmse = float(np.sqrt(np.mean(error**2)))
            metric_rows.append(
                {
                    "horizon": int(horizon),
                    "model": model,
                    "n": len(error),
                    "first_origin": group["origin_date"].min(),
                    "last_origin": group["origin_date"].max(),
                    "rmse": rmse,
                    "mae": float(np.mean(np.abs(error))),
                    "bias": float(np.mean(error)),
                    "relative_rmse_vs_ar": rmse / ar_rmse,
                }
            )

        nn = frame.loc[
            frame["model"] == "neural_network",
            ["origin_date", "actual", "forecast"],
        ].merge(ar, on="origin_date", suffixes=("_nn", "_ar"))
        dm, p_value, loss_diff = harvey_dm_test(
            nn["actual_nn"].to_numpy(),
            nn["forecast"].to_numpy(),
            nn["forecast_ar"].to_numpy(),
            int(horizon),
        )
        dm_rows.append(
            {
                "horizon": int(horizon),
                "model": "neural_network",
                "benchmark": "ar",
                "n": len(nn),
                "dm_harvey": dm,
                "p_value": p_value,
                "mean_loss_diff_ar_minus_model": loss_diff,
            }
        )

    metrics = pd.DataFrame(metric_rows).sort_values(["horizon", "rmse"])
    dm_tests = pd.DataFrame(dm_rows).sort_values(["horizon", "p_value"])
    metrics.to_csv(output_dir / "metrics_all_models_with_nn.csv", index=False)
    dm_tests.to_csv(output_dir / "dm_tests_nn_vs_ar.csv", index=False)

    # Regime tables are descriptive. In particular, do not treat short h=12
    # regimes as independent samples or as primary statistical evidence.
    for regime_column in ("origin_regime", "target_regime"):
        regime_source = combined.loc[
            combined["model"].isin(["ar", "neural_network"])
        ].copy()
        regime_rows: list[dict[str, Any]] = []
        for (horizon, regime), regime_frame in regime_source.groupby(
            ["horizon", regime_column]
        ):
            ar_frame = regime_frame.loc[regime_frame["model"] == "ar"]
            if ar_frame.empty:
                continue
            ar_error = ar_frame["actual"] - ar_frame["forecast"]
            ar_rmse = float(np.sqrt(np.mean(ar_error**2)))
            for model, group in regime_frame.groupby("model"):
                error = group["actual"] - group["forecast"]
                rmse = float(np.sqrt(np.mean(error**2)))
                regime_rows.append(
                    {
                        "horizon": int(horizon),
                        "regime_definition": regime_column,
                        "regime": regime,
                        "model": model,
                        "n": len(error),
                        "rmse": rmse,
                        "mae": float(np.mean(np.abs(error))),
                        "relative_rmse_vs_ar": rmse / ar_rmse,
                        "descriptive_only": (
                            int(horizon) == 12 and len(error) <= 36
                        ),
                    }
                )
        pd.DataFrame(regime_rows).to_csv(
            output_dir / f"metrics_{regime_column}_with_nn.csv", index=False
        )
    return metrics, dm_tests


# %% 7. Command-line entry point / 命令行入口
def main() -> None:
    args = parse_args()
    config = make_config(args)
    project_root = Path(__file__).resolve().parents[1]
    start_tag = pd.Timestamp(config.oos_start).strftime("%Y%m")
    seed_tag = "s" + "-".join(str(seed) for seed in config.seeds)
    origin_limit_tag = (
        f"_last{config.max_origins}" if config.max_origins is not None else ""
    )
    output_tag = (
        f"{config.mode}_{start_tag}_cv{config.cv_splits}_"
        f"cvtrain{config.min_train}_v2_"
        f"ilag{config.information_lag}_plags{config.predictor_lags}_{seed_tag}"
        f"{origin_limit_tag}"
    )
    output_dir = (
        args.output_dir.resolve()
        if args.output_dir is not None
        else project_root / "outputs" / "neural_network_ukmd" / output_tag
    )
    output_dir.mkdir(parents=True, exist_ok=True)

    horizon_tag = "-".join(str(h) for h in config.horizons)
    run_record = {
        **asdict(config),
        "numpy_version": np.__version__,
        "pandas_version": pd.__version__,
        "sklearn_version": sklearn.__version__,
    }
    (output_dir / f"run_config_h{horizon_tag}.json").write_text(
        json.dumps(run_record, indent=2), encoding="utf-8"
    )
    benchmark_path = (
        args.benchmark_predictions.resolve()
        if args.benchmark_predictions is not None
        else project_root / "outputs" / "full_with_random_forest" / "predictions.csv"
    )
    (output_dir / "run_metadata.json").write_text(
        json.dumps(
            {
                **run_record,
                "models": ["ar", "neural_network"],
                "benchmark_predictions": str(benchmark_path),
            },
            indent=2,
        ),
        encoding="utf-8",
    )

    print(json.dumps(asdict(config), indent=2))
    data, predictor_cols = load_ukmd(project_root, config.horizons)
    features = build_panel_features(
        data,
        predictor_cols,
        config.predictor_lags,
        config.information_lag,
    )
    print("Base UK-MD predictors:", len(predictor_cols))
    print("Lagged neural-network features:", features.shape[1])
    print("Hyperparameter combinations:", math.prod(
        [len(config.hidden_layers), len(config.alphas), len(config.learning_rates)]
    ))

    started = time.perf_counter()
    for horizon in config.horizons:
        run_one_horizon(
            data=data,
            features=features,
            horizon=horizon,
            config=config,
            checkpoint_path=output_dir / f"nn_predictions_h{horizon}.csv",
            tuning_path=output_dir / f"nn_tuning_h{horizon}.json",
        )

    prediction_files = sorted(output_dir.glob("nn_predictions_h*.csv"))
    nn_predictions = pd.concat(
        [
            pd.read_csv(
                path,
                parse_dates=[
                    "origin_date",
                    "target_date",
                    "latest_train_origin_date",
                    "latest_train_target_date",
                ],
            )
            for path in prediction_files
        ],
        ignore_index=True,
    )
    nn_predictions.to_csv(output_dir / "nn_predictions_all.csv", index=False)

    # Make the selected depth auditable instead of hiding it inside JSON files.
    tuning_rows: list[dict[str, Any]] = []
    for tuning_file in sorted(output_dir.glob("nn_tuning_h*.json")):
        for key, params in json.loads(
            tuning_file.read_text(encoding="utf-8")
        ).items():
            layers = params.get("model__hidden_layer_sizes", [])
            tuning_rows.append(
                {
                    "horizon_year": key,
                    "horizon": int(key.split("_")[0].removeprefix("h")),
                    "year": int(key.split("_")[1]),
                    "hidden_layer_sizes": json.dumps(layers),
                    "number_of_hidden_layers": len(layers),
                    "alpha_l2": params.get("model__alpha"),
                    "learning_rate_init": params.get(
                        "model__learning_rate_init"
                    ),
                }
            )
    if tuning_rows:
        tuning_summary = pd.DataFrame(tuning_rows).sort_values(
            ["horizon", "year"]
        )
        tuning_summary.to_csv(
            output_dir / "nn_hyperparameter_selection_by_year.csv", index=False
        )

    metrics, dm_tests = evaluate(
        nn_predictions,
        project_root,
        output_dir,
        benchmark_predictions=benchmark_path,
    )

    if not metrics.empty:
        print("\nNeural-network overall comparison / 神经网络总体比较")
        print(
            metrics.loc[metrics["model"].isin(["neural_network", "ar"])]
            .assign(
                rmse=lambda x: x["rmse"].round(4),
                mae=lambda x: x["mae"].round(4),
                bias=lambda x: x["bias"].round(4),
                relative_rmse_vs_ar=lambda x: x["relative_rmse_vs_ar"].round(4),
            )
            .to_string(index=False)
        )
        print("\nNeural-network DM tests against AR / 神经网络相对AR的DM检验")
        print(dm_tests.round(4).to_string(index=False))

    print(f"\nTotal runtime: {(time.perf_counter() - started) / 60:.2f} minutes")
    print("Outputs:", output_dir)


if __name__ == "__main__":
    main()
