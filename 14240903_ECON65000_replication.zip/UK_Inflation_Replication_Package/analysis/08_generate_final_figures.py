"""Generate publication-ready figures from frozen master predictions.

No forecasting model is estimated here.  Re-running this file only redraws
figures from ``outputs/final_master`` and the audited BBIM contribution tables.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
MASTER = ROOT / "outputs" / "final_master"
INTERPRETABILITY = ROOT / "outputs" / "interpretability"
OUTPUT = ROOT / "artifacts" / "final_figures"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--master-dir", type=Path, default=MASTER)
    parser.add_argument("--interpretability-dir", type=Path, default=INTERPRETABILITY)
    parser.add_argument("--output-dir", type=Path, default=OUTPUT)
    return parser.parse_args()

DISPLAY = {
    "historical_mean": "Historical mean",
    "naive": "Naive",
    "ar": "AR",
    "factor_ar": "Factor-AR",
    "ridge": "Ridge",
    "lasso": "LASSO",
    "random_forest": "Random Forest",
    "bbim_ukmd": "BBIM",
    "neural_network": "Neural Network",
}
MODEL_ORDER = list(DISPLAY)


def finish(fig: plt.Figure, filename: str) -> None:
    fig.tight_layout()
    fig.savefig(OUTPUT / filename, dpi=300, bbox_inches="tight")
    plt.close(fig)


def plot_relative_rmse(metrics: pd.DataFrame) -> None:
    fig, ax = plt.subplots(figsize=(8.3, 5.0))
    selected = ["ar", "factor_ar", "lasso", "random_forest", "bbim_ukmd", "neural_network"]
    for model in selected:
        subset = metrics.loc[metrics["model"].eq(model)].sort_values("horizon")
        ax.plot(
            subset["horizon"], subset["relative_rmse_vs_ar"], marker="o",
            linewidth=1.8, label=DISPLAY[model],
        )
    ax.axhline(1.0, color="black", linewidth=1.0, linestyle="--", alpha=0.75)
    ax.set_xticks([1, 3, 6, 12])
    ax.set_xlabel("Forecast horizon (months)")
    ax.set_ylabel("RMSE relative to AR")
    ax.set_title("Relative forecast accuracy varies materially by horizon")
    ax.grid(alpha=0.22)
    ax.legend(ncol=2, frameon=False)
    finish(fig, "figure_relative_rmse_by_horizon.png")


def forecast_path(predictions: pd.DataFrame, horizon: int, models: list[str], filename: str) -> None:
    frame = predictions.loc[
        predictions["horizon"].eq(horizon)
        & predictions["model"].isin(models)
        & (predictions["target_date"] >= pd.Timestamp("2018-01-01"))
    ].copy()
    actual = frame.drop_duplicates("target_date").sort_values("target_date")
    fig, ax = plt.subplots(figsize=(10.0, 4.8))
    ax.plot(actual["target_date"], actual["actual"], color="black", linewidth=2.0, label="Actual")
    for model in models:
        subset = frame.loc[frame["model"].eq(model)].sort_values("target_date")
        ax.plot(
            subset["target_date"], subset["forecast"], linewidth=1.35,
            label=DISPLAY[model], alpha=0.9,
        )
    ax.axvspan(pd.Timestamp("2020-01-01"), pd.Timestamp("2021-12-01"), color="#D9EAF7", alpha=0.35)
    ax.axvspan(pd.Timestamp("2022-01-01"), pd.Timestamp("2023-12-01"), color="#FCE4D6", alpha=0.35)
    ax.set_ylabel("Annualised inflation (%)")
    ax.set_xlabel("Target date")
    ax.set_title(f"Actual and forecast inflation, h={horizon}")
    ax.grid(alpha=0.20)
    ax.legend(ncol=len(models) + 1, frameon=False)
    finish(fig, filename)


def heatmap_table(
    table: pd.DataFrame,
    title: str,
    filename: str,
) -> None:
    matrix = table.reindex(index=MODEL_ORDER)
    values = matrix.to_numpy(dtype=float)
    fig, ax = plt.subplots(figsize=(9.2, 5.2))
    image = ax.imshow(values, cmap="RdYlGn_r", vmin=0.75, vmax=1.25, aspect="auto")
    ax.set_xticks(range(len(matrix.columns)), matrix.columns, rotation=25, ha="right")
    ax.set_yticks(range(len(matrix.index)), [DISPLAY[x] for x in matrix.index])
    for row in range(values.shape[0]):
        for col in range(values.shape[1]):
            value = values[row, col]
            if np.isfinite(value):
                ax.text(col, row, f"{value:.2f}", ha="center", va="center", fontsize=8)
    ax.set_title(title)
    colorbar = fig.colorbar(image, ax=ax, fraction=0.035, pad=0.03)
    colorbar.set_label("RMSE relative to AR")
    finish(fig, filename)


def plot_regimes(regimes: pd.DataFrame) -> None:
    four = regimes.loc[
        regimes["regime_basis"].eq("target_calendar")
        & regimes["horizon"].isin([1, 3, 6])
    ].copy()
    regime_order = [
        "pre_covid", "covid_2020_2021", "high_inflation_2022_2023",
        "disinflation_2024_plus",
    ]
    regime_labels = ["Pre-Covid", "Covid\n2020–21", "High inflation\n2022–23", "Disinflation\n2024+"]
    fig, axes = plt.subplots(1, 3, figsize=(14.5, 6.0), sharey=True)
    image = None
    for ax, horizon in zip(axes, [1, 3, 6]):
        matrix = four.loc[four["horizon"].eq(horizon)].pivot(
            index="model", columns="regime", values="relative_rmse_vs_ar"
        ).reindex(index=MODEL_ORDER, columns=regime_order)
        values = matrix.to_numpy(dtype=float)
        image = ax.imshow(values, cmap="RdYlGn_r", vmin=0.75, vmax=1.25, aspect="auto")
        ax.set_xticks(range(4), regime_labels, rotation=20, ha="right", fontsize=8)
        ax.set_title(f"h={horizon}")
        for row in range(values.shape[0]):
            for col in range(values.shape[1]):
                if np.isfinite(values[row, col]):
                    ax.text(col, row, f"{values[row, col]:.2f}", ha="center", va="center", fontsize=7)
    axes[0].set_yticks(range(len(MODEL_ORDER)), [DISPLAY[x] for x in MODEL_ORDER])
    fig.suptitle("Target-date regime performance at short and medium horizons")
    colorbar_axis = fig.add_axes([0.90, 0.20, 0.012, 0.60])
    colorbar = fig.colorbar(image, cax=colorbar_axis)
    colorbar.set_label("RMSE relative to AR")
    fig.subplots_adjust(left=0.15, right=0.88, top=0.88, bottom=0.20, wspace=0.08)
    fig.savefig(
        OUTPUT / "figure_target_regime_relative_rmse_h1_h3_h6.png",
        dpi=300,
        bbox_inches="tight",
    )
    plt.close(fig)
    broad = regimes.loc[
        regimes["regime_basis"].eq("target_broad_period")
        & regimes["horizon"].eq(12)
    ].pivot(index="model", columns="regime", values="relative_rmse_vs_ar").reindex(
        index=MODEL_ORDER, columns=["pre_2020", "2020_plus"]
    )
    broad.columns = ["Pre-2020", "2020 onward"]
    heatmap_table(
        broad,
        "Twelve-month performance: broad pre-2020 and 2020-onward samples",
        "figure_h12_broad_period_relative_rmse.png",
    )


def plot_bbim_blocks() -> None:
    path = INTERPRETABILITY / "bbim_block_contributions_by_horizon.csv"
    if not path.exists():
        return
    data = pd.read_csv(path)
    pivot = data.pivot(
        index="horizon", columns="block", values="absolute_share_within_horizon"
    ).sort_index()
    fig, ax = plt.subplots(figsize=(8.2, 4.8))
    pivot.plot(kind="bar", stacked=True, ax=ax, width=0.72)
    ax.set_xlabel("Forecast horizon (months)")
    ax.set_ylabel("Share of mean absolute BBIM contribution")
    ax.set_title("BBIM contributions become increasingly concentrated in the trend block")
    ax.yaxis.set_major_formatter(lambda value, _: f"{value:.0%}")
    ax.legend(title="Economic block", bbox_to_anchor=(1.02, 1), loc="upper left", frameon=False)
    finish(fig, "figure_bbim_block_contribution_shares.png")


def main() -> None:
    global MASTER, INTERPRETABILITY, OUTPUT
    args = parse_args()
    MASTER = args.master_dir.resolve()
    INTERPRETABILITY = args.interpretability_dir.resolve()
    OUTPUT = args.output_dir.resolve()
    OUTPUT.mkdir(parents=True, exist_ok=True)
    metrics = pd.read_csv(MASTER / "all_model_metrics.csv")
    predictions = pd.read_csv(
        MASTER / "all_model_predictions.csv", parse_dates=["origin_date", "target_date"]
    )
    regimes = pd.read_csv(MASTER / "all_model_regime_metrics.csv")
    plot_relative_rmse(metrics)
    forecast_path(
        predictions, 6, ["ar", "random_forest", "bbim_ukmd"],
        "figure_forecast_path_h6.png",
    )
    forecast_path(
        predictions, 12, ["ar", "bbim_ukmd", "neural_network"],
        "figure_forecast_path_h12.png",
    )
    plot_regimes(regimes)
    plot_bbim_blocks()
    manifest = pd.DataFrame(
        [
            {"file": path.name, "source": "outputs/final_master and outputs/interpretability"}
            for path in sorted(OUTPUT.glob("*.png"))
        ]
    )
    manifest.to_csv(OUTPUT / "figure_manifest.csv", index=False)
    print(f"Saved {len(manifest)} final figures to {OUTPUT}")


if __name__ == "__main__":
    main()
