"""Summarise completed robustness runs against the frozen primary forecasts.

The script never estimates a model.  It scans ``outputs/robustness`` for runs
whose directory name starts with ``main_``, evaluates each run on its own sample,
and compares it with the primary specification on exactly the same forecast
origin dates.  This matched-sample rule is essential for OOS-start and rolling-
window checks.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from scipy import stats


PROJECT_ROOT = Path(__file__).resolve().parents[1]
PRIMARY_PATH = PROJECT_ROOT / "outputs" / "final_master" / "all_model_predictions.csv"
ROBUSTNESS_ROOT = PROJECT_ROOT / "outputs" / "robustness"
OUTPUT_DIR = ROBUSTNESS_ROOT / "summary"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--robustness-root", type=Path, default=ROBUSTNESS_ROOT)
    parser.add_argument("--output-dir", type=Path, default=OUTPUT_DIR)
    parser.add_argument("--include-smoke", action="store_true")
    return parser.parse_args()


def metrics(errors: pd.Series) -> dict[str, float]:
    values = errors.to_numpy(dtype=float)
    return {
        "rmse": float(np.sqrt(np.mean(values**2))),
        "mae": float(np.mean(np.abs(values))),
        "bias": float(np.mean(values)),
    }


def dm_harvey(a: np.ndarray, b: np.ndarray, horizon: int) -> tuple[float, float, float]:
    # Re-running an unchanged deterministic benchmark can create differences
    # around 1e-16 from CSV round-tripping.  This is identity, not a statistical
    # comparison, so exclude it from multiplicity counts.
    if np.allclose(a, b, rtol=1e-12, atol=1e-12, equal_nan=True):
        return 0.0, np.nan, 0.0
    differential = np.asarray(a, dtype=float) ** 2 - np.asarray(b, dtype=float) ** 2
    differential = differential[np.isfinite(differential)]
    n = len(differential)
    if n < max(8, horizon + 3):
        return np.nan, np.nan, float(differential.mean()) if n else np.nan
    centered = differential - differential.mean()
    max_lag = min(horizon - 1, n - 2)
    variance = float(np.dot(centered, centered) / n)
    for lag in range(1, max_lag + 1):
        covariance = float(np.dot(centered[lag:], centered[:-lag]) / n)
        variance += 2 * (1 - lag / (max_lag + 1)) * covariance
    if variance <= 0 or not np.isfinite(variance):
        return np.nan, np.nan, float(differential.mean())
    statistic = float(differential.mean() / np.sqrt(variance / n))
    adjustment = (n + 1 - 2 * horizon + horizon * (horizon - 1) / n) / n
    if adjustment <= 0:
        return np.nan, np.nan, float(differential.mean())
    statistic *= math.sqrt(adjustment)
    return (
        statistic,
        float(2 * stats.t.sf(abs(statistic), df=n - 1)),
        float(differential.mean()),
    )


def holm_adjust(values: pd.Series) -> pd.Series:
    """Holm step-down adjustment, preserving missing values and row order."""
    result = pd.Series(np.nan, index=values.index, dtype=float)
    finite = values.dropna().astype(float).sort_values()
    if finite.empty:
        return result
    m = len(finite)
    adjusted_sorted = np.maximum.accumulate(
        [(m - rank) * value for rank, value in enumerate(finite.to_numpy())]
    )
    result.loc[finite.index] = np.minimum(adjusted_sorted, 1.0)
    return result


def multiplicity_family(run: str) -> str:
    """Join computationally separate runs that test one economic specification."""
    if run in {
        "main_ilag1_full_expanding",
        "main_bbim_ilag1_h6",
        "main_nn_ilag1_h12",
    }:
        return "information_lag_1"
    if run.startswith("main_core_h"):
        return "core_panel"
    if run.startswith("main_rolling120_h"):
        return "rolling_120_months"
    if run in {"main_ar_lags2", "main_ar_lags6"}:
        return "alternative_ar_lags"
    if run.startswith("main_rf_seed"):
        return "random_forest_seed_stability"
    if run == "main_bbim_nomono_h6":
        return "bbim_monotonicity"
    return run


def load_run(path: Path) -> tuple[pd.DataFrame, dict[str, Any]]:
    predictions = pd.read_csv(
        path / "predictions.csv", parse_dates=["origin_date", "target_date"]
    )
    predictions["error"] = predictions["actual"] - predictions["forecast"]
    metadata_path = path / "run_metadata.json"
    metadata = json.loads(metadata_path.read_text(encoding="utf-8")) if metadata_path.exists() else {}
    return predictions, metadata


def main() -> None:
    args = parse_args()
    root = args.robustness_root.resolve()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    primary = pd.read_csv(PRIMARY_PATH, parse_dates=["origin_date", "target_date"])
    primary["error"] = primary["actual"] - primary["forecast"]

    candidates = sorted(path.parent for path in root.glob("*/predictions.csv"))
    if not args.include_smoke:
        candidates = [path for path in candidates if path.name.startswith("main_")]
    if not candidates:
        print(f"No completed robustness runs found below {root}")
        return

    metric_rows: list[dict[str, Any]] = []
    comparison_rows: list[dict[str, Any]] = []
    specification_dm_rows: list[dict[str, Any]] = []
    dm_rows: list[dict[str, Any]] = []
    alternative_ar_rows: list[dict[str, Any]] = []
    design_rows: list[dict[str, Any]] = []
    for path in candidates:
        run, metadata = load_run(path)
        design_rows.append({"run": path.name, "path": str(path), **metadata})
        for (horizon, model), group in run.groupby(["horizon", "model"], sort=True):
            own = metrics(group["error"])
            metric_rows.append(
                {
                    "run": path.name,
                    "horizon": int(horizon),
                    "model": model,
                    "n": len(group),
                    "first_origin": group["origin_date"].min(),
                    "last_origin": group["origin_date"].max(),
                    **own,
                }
            )
            primary_group = primary.loc[
                primary["horizon"].eq(horizon) & primary["model"].eq(model),
                ["origin_date", "actual", "error"],
            ].rename(columns={"actual": "actual_primary", "error": "error_primary"})
            matched = group[["origin_date", "actual", "error"]].merge(
                primary_group, on="origin_date", how="inner", validate="one_to_one"
            )
            if not np.allclose(matched["actual"], matched["actual_primary"], atol=1e-10):
                raise ValueError(f"Actual values differ for {path.name}, h={horizon}, {model}")
            primary_metrics = metrics(matched["error_primary"])
            robust_metrics = metrics(matched["error"])
            comparison_rows.append(
                {
                    "run": path.name,
                    "horizon": int(horizon),
                    "model": model,
                    "n_matched": len(matched),
                    "robust_rmse": robust_metrics["rmse"],
                    "primary_rmse_matched": primary_metrics["rmse"],
                    "robust_to_primary_rmse_ratio": (
                        robust_metrics["rmse"] / primary_metrics["rmse"]
                    ),
                    "robust_mae": robust_metrics["mae"],
                    "primary_mae_matched": primary_metrics["mae"],
                    "robust_to_primary_mae_ratio": (
                        robust_metrics["mae"] / primary_metrics["mae"]
                    ),
                }
            )
            dm_stat, dm_p, dm_mean = dm_harvey(
                matched["error"].to_numpy(),
                matched["error_primary"].to_numpy(),
                int(horizon),
            )
            specification_dm_rows.append(
                {
                    "run": path.name,
                    "horizon": int(horizon),
                    "model": model,
                    "benchmark_specification": "primary_expanding",
                    "n": len(matched),
                    "robust_to_primary_rmse_ratio": (
                        robust_metrics["rmse"] / primary_metrics["rmse"]
                    ),
                    "dm_harvey": dm_stat,
                    "p_value_raw": dm_p,
                    "mean_loss_diff_robust_minus_primary": dm_mean,
                }
            )

        for horizon, group in run.groupby("horizon", sort=True):
            ar = group.loc[group["model"].eq("ar"), ["origin_date", "error"]].rename(
                columns={"error": "error_ar"}
            )
            if ar.empty:
                continue
            ar_rmse = metrics(ar["error_ar"])["rmse"]
            for model, candidate in group.groupby("model", sort=True):
                if model == "ar":
                    continue
                matched = candidate[["origin_date", "error"]].merge(
                    ar, on="origin_date", how="inner", validate="one_to_one"
                )
                statistic, p_value, mean_diff = dm_harvey(
                    matched["error"].to_numpy(),
                    matched["error_ar"].to_numpy(),
                    int(horizon),
                )
                candidate_rmse = metrics(matched["error"])["rmse"]
                dm_rows.append(
                    {
                        "run": path.name,
                        "horizon": int(horizon),
                        "model": model,
                        "benchmark": "ar",
                        "n": len(matched),
                        "relative_rmse_vs_ar": candidate_rmse / ar_rmse,
                        "dm_harvey": statistic,
                        "p_value_raw": p_value,
                        "mean_loss_diff_model_minus_ar": mean_diff,
                    }
                )

        # AR(2) and AR(6) are alternative benchmark forecasts.  Besides the
        # direct comparison with primary AR(12) above, compare every frozen
        # primary candidate with each alternative AR on identical origins.
        # This does not re-estimate or select a model after seeing the result.
        if path.name in {"main_ar_lags2", "main_ar_lags6"}:
            benchmark_lags = int(path.name.removeprefix("main_ar_lags"))
            for horizon, benchmark_group in run.groupby("horizon", sort=True):
                benchmark = benchmark_group.loc[
                    benchmark_group["model"].eq("ar"),
                    ["origin_date", "actual", "error"],
                ].rename(
                    columns={"actual": "actual_benchmark", "error": "error_benchmark"}
                )
                primary_horizon = primary.loc[
                    primary["horizon"].eq(horizon) & ~primary["model"].eq("ar")
                ]
                for model, candidate in primary_horizon.groupby("model", sort=True):
                    matched = candidate[["origin_date", "actual", "error"]].merge(
                        benchmark,
                        on="origin_date",
                        how="inner",
                        validate="one_to_one",
                    )
                    if not np.allclose(
                        matched["actual"], matched["actual_benchmark"], atol=1e-10
                    ):
                        raise ValueError(
                            f"Actual values differ for {path.name}, h={horizon}, {model}"
                        )
                    statistic, p_value, mean_diff = dm_harvey(
                        matched["error"].to_numpy(),
                        matched["error_benchmark"].to_numpy(),
                        int(horizon),
                    )
                    candidate_rmse = metrics(matched["error"])["rmse"]
                    benchmark_rmse = metrics(matched["error_benchmark"])["rmse"]
                    alternative_ar_rows.append(
                        {
                            "benchmark_run": path.name,
                            "benchmark_ar_lags": benchmark_lags,
                            "horizon": int(horizon),
                            "model": model,
                            "n": len(matched),
                            "model_rmse": candidate_rmse,
                            "benchmark_rmse": benchmark_rmse,
                            "relative_rmse_vs_alternative_ar": (
                                candidate_rmse / benchmark_rmse
                            ),
                            "dm_harvey": statistic,
                            "p_value_raw": p_value,
                            "mean_loss_diff_model_minus_benchmark": mean_diff,
                        }
                    )

    pd.DataFrame(metric_rows).to_csv(output_dir / "robustness_metrics.csv", index=False)
    pd.DataFrame(comparison_rows).to_csv(
        output_dir / "robustness_vs_primary_matched.csv", index=False
    )
    specification_dm_table = pd.DataFrame(specification_dm_rows)
    if not specification_dm_table.empty:
        specification_dm_table["multiplicity_family"] = specification_dm_table[
            "run"
        ].map(multiplicity_family)
        specification_dm_table["p_value_holm"] = specification_dm_table.groupby(
            ["multiplicity_family", "horizon"], group_keys=False
        )["p_value_raw"].apply(holm_adjust)
        specification_dm_table["reject_5pct_holm"] = (
            specification_dm_table["p_value_holm"] < 0.05
        )
    specification_dm_table.to_csv(
        output_dir / "robustness_dm_vs_primary_matched.csv", index=False
    )
    dm_table = pd.DataFrame(dm_rows)
    if not dm_table.empty:
        dm_table["multiplicity_family"] = dm_table["run"].map(multiplicity_family)
        dm_table["p_value_holm"] = dm_table.groupby(
            ["multiplicity_family", "horizon"], group_keys=False
        )["p_value_raw"].apply(holm_adjust)
        dm_table["reject_5pct_holm"] = dm_table["p_value_holm"] < 0.05
    dm_table.to_csv(output_dir / "robustness_dm_vs_ar.csv", index=False)
    alternative_ar_table = pd.DataFrame(alternative_ar_rows)
    if not alternative_ar_table.empty:
        # Both lag choices and all candidate models comprise one pre-specified
        # benchmark-sensitivity family at each horizon.
        alternative_ar_table["multiplicity_family"] = "alternative_ar_lags"
        alternative_ar_table["p_value_holm"] = alternative_ar_table.groupby(
            ["multiplicity_family", "horizon"], group_keys=False
        )["p_value_raw"].apply(holm_adjust)
        alternative_ar_table["reject_5pct_holm"] = (
            alternative_ar_table["p_value_holm"] < 0.05
        )
    alternative_ar_table.to_csv(
        output_dir / "alternative_ar_benchmark_dm.csv", index=False
    )

    # A later evaluation start is an evaluation-sample check, not a new model
    # run.  Under expanding estimation the saved forecasts already contain the
    # correct vintage-specific training samples, so re-estimation would only
    # duplicate the same forecasts.
    post_2018 = primary.loc[primary["origin_date"] >= pd.Timestamp("2018-01-01")].copy()
    post_2018_metric_rows: list[dict[str, Any]] = []
    post_2018_dm_rows: list[dict[str, Any]] = []
    for horizon, group in post_2018.groupby("horizon", sort=True):
        ar = group.loc[group["model"].eq("ar"), ["origin_date", "error"]].rename(
            columns={"error": "error_ar"}
        )
        ar_rmse = metrics(ar["error_ar"])["rmse"]
        for model, candidate in group.groupby("model", sort=True):
            own = metrics(candidate["error"])
            post_2018_metric_rows.append(
                {
                    "evaluation_start_origin": "2018-01-01",
                    "horizon": int(horizon),
                    "model": model,
                    "n": len(candidate),
                    "first_origin": candidate["origin_date"].min(),
                    "last_origin": candidate["origin_date"].max(),
                    **own,
                    "relative_rmse_vs_ar": own["rmse"] / ar_rmse,
                }
            )
            if model == "ar":
                continue
            matched = candidate[["origin_date", "error"]].merge(
                ar, on="origin_date", how="inner", validate="one_to_one"
            )
            statistic, p_value, mean_diff = dm_harvey(
                matched["error"].to_numpy(),
                matched["error_ar"].to_numpy(),
                int(horizon),
            )
            post_2018_dm_rows.append(
                {
                    "evaluation_start_origin": "2018-01-01",
                    "horizon": int(horizon),
                    "model": model,
                    "benchmark": "ar",
                    "n": len(matched),
                    "relative_rmse_vs_ar": own["rmse"] / ar_rmse,
                    "dm_harvey": statistic,
                    "p_value_raw": p_value,
                    "mean_loss_diff_model_minus_ar": mean_diff,
                }
            )
    post_2018_metrics = pd.DataFrame(post_2018_metric_rows)
    if not post_2018_metrics.empty:
        post_2018_metrics["rmse_rank_within_horizon"] = post_2018_metrics.groupby(
            "horizon"
        )["rmse"].rank(method="min")
    post_2018_metrics.to_csv(
        output_dir / "primary_oos_from_2018_metrics.csv", index=False
    )
    post_2018_dm = pd.DataFrame(post_2018_dm_rows)
    if not post_2018_dm.empty:
        post_2018_dm["multiplicity_family"] = "primary_oos_from_2018"
        post_2018_dm["p_value_holm"] = post_2018_dm.groupby(
            ["multiplicity_family", "horizon"], group_keys=False
        )["p_value_raw"].apply(holm_adjust)
        post_2018_dm["reject_5pct_holm"] = post_2018_dm["p_value_holm"] < 0.05
    post_2018_dm.to_csv(
        output_dir / "primary_oos_from_2018_dm_vs_ar.csv", index=False
    )
    pd.DataFrame(design_rows).to_csv(output_dir / "robustness_run_registry.csv", index=False)
    print(f"Summarised {len(candidates)} completed runs in: {output_dir}")


if __name__ == "__main__":
    main()
