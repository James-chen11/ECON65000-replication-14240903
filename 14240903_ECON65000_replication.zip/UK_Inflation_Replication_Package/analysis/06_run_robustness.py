r"""List or execute pre-specified dissertation robustness runs.

The default action only prints the registry. Use ``--run R2_CORE_H6`` (one or
more IDs) to launch selected jobs. Expensive jobs are separated by horizon so
an interruption does not erase every horizon.
"""

from __future__ import annotations

import argparse
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PYTHON = Path(sys.executable)


@dataclass(frozen=True)
class Job:
    job_id: str
    purpose: str
    command: tuple[str, ...]
    priority: str = "core"


def pipeline_job(
    job_id: str,
    purpose: str,
    output_name: str,
    extra: list[str],
    priority: str = "core",
) -> Job:
    command = (
        str(PYTHON),
        str(ROOT / "src" / "forecast_pipeline.py"),
        *extra,
        "--output-dir",
        str(ROOT / "outputs" / "robustness" / output_name),
    )
    return Job(job_id, purpose, command, priority)


COMMON_MODELS = [
    "--models", "historical_mean", "naive", "ar", "factor_ar", "ridge",
    "lasso", "random_forest",
]

JOBS: list[Job] = []
JOBS.append(
    pipeline_job(
        "R1_ILAG1_FULL",
        "Full predictor panel with a one-month information lag",
        "main_ilag1_full_expanding",
        [
            "--horizons", "1", "3", "6", "12", *COMMON_MODELS,
            "--information-lag", "1",
        ],
    )
)
for horizon in (1, 3, 6, 12):
    JOBS.append(
        pipeline_job(
            f"R2_CORE_H{horizon}",
            f"Theory-guided core predictor panel, h={horizon}",
            f"main_core_h{horizon}",
            ["--horizons", str(horizon), *COMMON_MODELS, "--variable-set", "core"],
        )
    )
    JOBS.append(
        pipeline_job(
            f"R3_ROLLING_H{horizon}",
            f"Rolling 10-year estimation window, h={horizon}",
            f"main_rolling120_h{horizon}",
            [
                "--horizons", str(horizon), *COMMON_MODELS,
                "--window", "rolling", "--rolling-months", "120",
            ],
        )
    )

for ar_lags in (2, 6):
    JOBS.append(
        pipeline_job(
            f"R4_ARLAGS_{ar_lags}",
            f"Alternative direct AR benchmark with {ar_lags} monthly lags",
            f"main_ar_lags{ar_lags}",
            [
                "--horizons", "1", "3", "6", "12", "--models", "ar",
                "--ar-lags", str(ar_lags),
            ],
        )
    )

for seed in (61352, 61353):
    JOBS.append(
        pipeline_job(
            f"R5_RF_SEED_{seed}_H6",
            f"Random-Forest seed stability at the central h=6 horizon ({seed})",
            f"main_rf_seed{seed}_h6",
            [
                "--horizons", "6", "--models", "ar", "random_forest",
                "--seed", str(seed),
            ],
        )
    )

JOBS.extend(
    [
        Job(
            "R6_BBIM_ILAG1_H6",
            "BBIM with one-month information lag at h=6",
            (
                str(PYTHON), str(ROOT / "analysis" / "03_bbim_ukmd_paper_style.py"),
                "--mode", "paper", "--horizons", "6", "--information-lag", "1",
                "--benchmark-predictions",
                str(ROOT / "outputs" / "robustness" / "main_ilag1_full_expanding" / "predictions.csv"),
                "--output-dir",
                str(ROOT / "outputs" / "robustness" / "main_bbim_ilag1_h6"),
            ),
        ),
        Job(
            "R7_BBIM_NOMONO_H6",
            "BBIM without monotonicity constraints at h=6",
            (
                str(PYTHON), str(ROOT / "analysis" / "03_bbim_ukmd_paper_style.py"),
                "--mode", "paper", "--horizons", "6", "--no-monotone",
                "--output-dir",
                str(ROOT / "outputs" / "robustness" / "main_bbim_nomono_h6"),
            ),
        ),
        Job(
            "R8_NN_ILAG1_H12",
            "Neural network with one-month information lag at h=12",
            (
                str(PYTHON), str(ROOT / "analysis" / "04_neural_network_ukmd.py"),
                "--mode", "paper", "--horizons", "12", "--information-lag", "1",
                "--benchmark-predictions",
                str(ROOT / "outputs" / "robustness" / "main_ilag1_full_expanding" / "predictions.csv"),
                "--output-dir",
                str(ROOT / "outputs" / "robustness" / "main_nn_ilag1_h12"),
            ),
        ),
        pipeline_job(
            "R9_H24",
            "Optional 24-month horizon extension",
            "main_h24_optional",
            ["--horizons", "24", *COMMON_MODELS],
            priority="optional_appendix",
        ),
    ]
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", nargs="+", default=[])
    parser.add_argument("--dry-run", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    registry = {job.job_id: job for job in JOBS}
    if not args.run:
        print("Available robustness jobs (nothing is run):")
        for job in JOBS:
            print(f"{job.job_id:22s} [{job.priority}] {job.purpose}")
        return

    unknown = sorted(set(args.run).difference(registry))
    if unknown:
        raise KeyError(f"Unknown robustness job IDs: {unknown}")

    for job_id in args.run:
        job = registry[job_id]
        print(f"\n[{job.job_id}] {job.purpose}", flush=True)
        print(subprocess.list2cmdline(job.command), flush=True)
        if not args.dry_run:
            subprocess.run(job.command, cwd=ROOT, check=True)


if __name__ == "__main__":
    main()
