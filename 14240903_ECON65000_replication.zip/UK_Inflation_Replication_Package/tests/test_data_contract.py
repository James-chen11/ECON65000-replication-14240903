import sys
import unittest
from pathlib import Path

import numpy as np
import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from forecast_pipeline import CORE_VARIABLES, build_feature_frames, load_data  # noqa: E402


class DataContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data, cls.predictors = load_data(
            PROJECT_ROOT / "data" / "UKMD_March_2026", [1, 12, 24]
        )

    def test_balanced_panel_is_unique_and_monthly(self):
        dates = self.data["Date"]
        self.assertTrue(dates.is_unique)
        month_steps = dates.dt.to_period("M").astype(int).diff().dropna()
        self.assertTrue((month_steps == 1).all())

    def test_targets_match_documented_formula(self):
        log_cpi = np.log(self.data["CPI_ALL_INDEX"])
        for horizon in (1, 12, 24):
            expected = (1200.0 / horizon) * (
                log_cpi.shift(-horizon) - log_cpi
            )
            np.testing.assert_allclose(
                self.data[f"target_h{horizon}"],
                expected,
                rtol=1e-12,
                atol=1e-12,
                equal_nan=True,
            )

    def test_feature_dimensions_are_explicit(self):
        panel, ar = build_feature_frames(
            self.data, self.predictors, panel_lags=4, ar_lags=12
        )
        self.assertEqual(panel.shape[1], (len(self.predictors) + 2) * 4)
        self.assertEqual(ar.shape[1], 12)
        self.assertEqual(len(panel), len(self.data))

    def test_information_lag_moves_every_feature_back_one_month(self):
        panel_zero, ar_zero = build_feature_frames(
            self.data, self.predictors, panel_lags=4, ar_lags=12, information_lag=0
        )
        panel_one, ar_one = build_feature_frames(
            self.data, self.predictors, panel_lags=4, ar_lags=12, information_lag=1
        )
        np.testing.assert_allclose(
            panel_one.iloc[1:].to_numpy(),
            panel_zero.iloc[:-1].to_numpy(),
            rtol=0,
            atol=0,
            equal_nan=True,
        )
        np.testing.assert_allclose(
            ar_one.iloc[1:].to_numpy(),
            ar_zero.iloc[:-1].to_numpy(),
            rtol=0,
            atol=0,
            equal_nan=True,
        )

    def test_core_robustness_variables_are_available(self):
        self.assertTrue(set(CORE_VARIABLES).issubset(self.predictors))
        self.assertLess(len(CORE_VARIABLES), len(self.predictors))

    def test_horizon_gap_ends_training_target_at_forecast_origin(self):
        origin_idx = 250
        for horizon in (1, 12, 24):
            last_train_origin = origin_idx - horizon
            target_endpoint = self.data.at[
                last_train_origin, "Date"
            ] + pd.DateOffset(months=horizon)
            self.assertEqual(target_endpoint, self.data.at[origin_idx, "Date"])


if __name__ == "__main__":
    unittest.main()
