"""Leakage-aware pseudo-out-of-sample forecasts for UK CPI inflation."""

from __future__ import annotations

import argparse
import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.compose import ColumnTransformer
from sklearn.decomposition import PCA
from sklearn.ensemble import RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.linear_model import Lasso, LinearRegression, Ridge
from sklearn.metrics import mean_absolute_error, mean_squared_error
from sklearn.model_selection import GridSearchCV, TimeSeriesSplit
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler


DEFAULT_HORIZONS = (1, 3, 6, 12, 24)
DEFAULT_MODELS = (
    "historical_mean",
    "naive",
    "ar",
    "factor_ar",
    "ridge",
    "lasso",
    "random_forest",
)

# Theory-guided robustness subset.  It uses only variables available in the
# March-2026 balanced UK-MD panel and is intentionally fixed before looking at
# the robustness results.
CORE_VARIABLES = (
    "CPIH_ALL", "CPI_ALL", "CPI_EX_ENER", "CPI_GOOD", "CPI_SERV",
    "CPI_TRANS", "RPI_ALL", "PPI_MANU", "PPI_OIL", "PPI_METAL",
    "EMP", "EMP_RATE", "UNEMP_RATE", "CLAIMS_RATE", "AWE_ALL",
    "AWE_PRIV", "AWE_PUB", "VAC_TOT", "TOT_WEEK_HRS",
    "IOP_PROD", "IOP_MANU", "IOP_ENER", "IOS", "RSI",
    "RETAIL_TRADE_INDEX", "CAR_REGIS", "GBP_BROAD", "GBP_US", "GBP_EUR",
    "OIL_PRICE", "IMP_ALL", "IMP_FUEL", "IMP_OIL", "BANK_RATE", "SONIA",
    "LIBOR_3mth", "BGS_5yrs_yld", "BGS_10yrs_yld", "M4", "FTSE_ALL",
    "VIX", "TOT_HOUSE_APP", "MORT_FIXED_RATE_2YRS",
    "MORT_FIXED_RATE_5YRS", "CONS_CREDIT_ex_student_loan", "SP500", "BCI",
    "CCI", "CLI", "EUR_UNC_INDEX",
)


@dataclass(frozen=True)
class ModelSpec:
    estimator: Any
    param_grid: dict[str, list[Any]] | None = None


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--data-dir",
        type=Path,
        default=Path("data/UKMD_March_2026"),
    )
    parser.add_argument(
        "--output-dir", type=Path, default=Path("outputs/baseline")
    )
    parser.add_argument("--oos-start", default="2008-01-01")
    parser.add_argument(
        "--horizons",
        nargs="+",
        type=int,
        default=list(DEFAULT_HORIZONS),
    )
    parser.add_argument(
        "--models", nargs="+", choices=DEFAULT_MODELS, default=list(DEFAULT_MODELS)
    )
    parser.add_argument("--panel-lags", type=int, default=4)
    parser.add_argument("--ar-lags", type=int, default=12)
    parser.add_argument("--information-lag", type=int, choices=(0, 1), default=0)
    parser.add_argument("--variable-set", choices=("full", "core"), default="full")
    parser.add_argument("--window", choices=("expanding", "rolling"), default="expanding")
    parser.add_argument("--rolling-months", type=int, default=120)
    parser.add_argument("--min-train", type=int, default=72)
    parser.add_argument("--cv-splits", type=int, default=5)
    parser.add_argument("--rf-estimators", type=int, default=300)
    parser.add_argument(
        "--max-origins",
        type=int,
        default=None,
        help="Keep only the final N origins at each horizon; useful for smoke tests.",
    )
    parser.add_argument("--seed", type=int, default=61351)
    parser.add_argument(
        "--smoke",
        action="store_true",
        help="Run the final 6 forecast origins for horizons 1 and 12.",
    )
    return parser.parse_args()


def load_data(data_dir: Path, horizons: list[int]) -> tuple[pd.DataFrame, list[str]]:
    raw = pd.read_csv(data_dir / "raw_uk_md.csv")
    balanced = pd.read_csv(data_dir / "balanced_uk_md.csv")

    for frame in (raw, balanced):
        frame.drop(columns=["Unnamed: 0"], errors="ignore", inplace=True)

    raw = raw.loc[raw["Date"].astype(str) != "Transform"].copy()
    raw["Date"] = pd.to_datetime(raw["Date"])
    raw["CPI_ALL"] = pd.to_numeric(raw["CPI_ALL"], errors="coerce")
    raw.sort_values("Date", inplace=True)

    balanced["Date"] = pd.to_datetime(balanced["Date"])
    balanced.sort_values("Date", inplace=True)
    predictor_cols = [c for c in balanced.columns if c != "Date"]
    balanced[predictor_cols] = balanced[predictor_cols].apply(
        pd.to_numeric, errors="coerce"
    )

    cpi = raw[["Date", "CPI_ALL"]].dropna().copy()
    cpi.rename(columns={"CPI_ALL": "CPI_ALL_INDEX"}, inplace=True)
    log_cpi = np.log(cpi["CPI_ALL_INDEX"])
    cpi["infl_mom_ann"] = 1200.0 * log_cpi.diff(1)
    cpi["infl_yoy"] = 100.0 * log_cpi.diff(12)
    for horizon in horizons:
        cpi[f"target_h{horizon}"] = (1200.0 / horizon) * (
            log_cpi.shift(-horizon) - log_cpi
        )

    merged = balanced.merge(cpi, on="Date", how="left", validate="one_to_one")
    merged.replace([np.inf, -np.inf], np.nan, inplace=True)
    return merged, predictor_cols


def build_feature_frames(
    data: pd.DataFrame,
    predictor_cols: list[str],
    panel_lags: int,
    ar_lags: int,
    information_lag: int = 0,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    panel_parts: list[pd.DataFrame] = []
    panel_base = predictor_cols + ["infl_mom_ann", "infl_yoy"]
    for lag in range(information_lag, information_lag + panel_lags):
        shifted = data[panel_base].shift(lag)
        shifted.columns = [f"{c}_lag{lag}" for c in panel_base]
        panel_parts.append(shifted)
    panel = pd.concat(panel_parts, axis=1)

    ar_parts: list[pd.Series] = []
    for lag in range(information_lag, information_lag + ar_lags):
        ar_parts.append(data["infl_mom_ann"].shift(lag).rename(f"infl_lag{lag}"))
    ar = pd.concat(ar_parts, axis=1)
    return panel, ar


def make_specs(
    seed: int,
    n_features: int,
    n_train: int,
    smoke: bool,
    factor_panel_count: int,
    factor_ar_term_count: int,
    rf_estimators: int,
) -> dict[str, ModelSpec]:
    # The literature motivates the architecture and conservative ex-ante grids;
    # it does not establish that a published setting is automatically suitable
    # for UK-MD.  The grids below have distinct economic/statistical roles:
    # ridge tests dense shrinkage, LASSO tests sparse signals, and the Random
    # Forest grid limits variance and extrapolation risk in a short monthly panel.
    # Suitability is decided by chronological validation, never final OOS losses.
    factor_count = max(1, min(5, factor_panel_count, n_train - 1))
    scaled_linear = lambda model: Pipeline(
        [
            ("imputer", SimpleImputer(strategy="median")),
            ("scale", StandardScaler()),
            ("model", model),
        ]
    )

    specs = {
        "ar": ModelSpec(
            Pipeline(
                [
                    ("imputer", SimpleImputer(strategy="median")),
                    ("model", LinearRegression()),
                ]
            )
        ),
        "factor_ar": ModelSpec(
            Pipeline(
                [
                    (
                        "features",
                        ColumnTransformer(
                            [
                                (
                                    "factors",
                                    Pipeline(
                                        [
                                            ("imputer", SimpleImputer(strategy="median")),
                                            ("scale", StandardScaler()),
                                            (
                                                "pca",
                                                PCA(
                                                    n_components=factor_count,
                                                    random_state=seed,
                                                ),
                                            ),
                                        ]
                                    ),
                                    list(range(factor_panel_count)),
                                ),
                                (
                                    "ar_terms",
                                    Pipeline(
                                        [
                                            ("imputer", SimpleImputer(strategy="median")),
                                            ("scale", StandardScaler()),
                                        ]
                                    ),
                                    list(
                                        range(
                                            factor_panel_count,
                                            factor_panel_count + factor_ar_term_count,
                                        )
                                    ),
                                ),
                            ]
                        ),
                    ),
                    ("model", Ridge(alpha=1.0)),
                ]
            )
        ),
        "ridge": ModelSpec(
            scaled_linear(Ridge()),
            {"model__alpha": [0.1, 1.0, 10.0, 100.0]},
        ),
        "lasso": ModelSpec(
            scaled_linear(Lasso(max_iter=30_000, random_state=seed)),
            {"model__alpha": [0.001, 0.01, 0.05, 0.1, 0.5]},
        ),
        "random_forest": ModelSpec(
            Pipeline(
                [
                    ("imputer", SimpleImputer(strategy="median")),
                    (
                        "model",
                        RandomForestRegressor(
                            n_estimators=80 if smoke else rf_estimators,
                            n_jobs=1,
                            random_state=seed,
                            bootstrap=True,
                            criterion="squared_error",
                        ),
                    ),
                ]
            ),
            (
                {
                    "model__max_features": ["sqrt"],
                    "model__min_samples_leaf": [2],
                }
                if smoke
                else {
                    "model__max_features": ["sqrt", 0.33],
                    "model__min_samples_leaf": [2, 5],
                    "model__max_depth": [None, 8],
                }
            ),
        ),
    }
    return specs


def tune_if_needed(
    spec: ModelSpec,
    x_train: pd.DataFrame,
    y_train: pd.Series,
    horizon: int,
    cv_splits: int,
) -> tuple[Any, dict[str, Any]]:
    if not spec.param_grid:
        estimator = clone(spec.estimator).fit(x_train, y_train)
        return estimator, {}

    # The gap prevents overlapping h-step targets immediately before the
    # validation fold from leaking horizon-specific outcome information.
    gap = min(horizon, max(0, len(y_train) // 8))
    splitter = TimeSeriesSplit(n_splits=cv_splits, gap=gap)
    search = GridSearchCV(
        clone(spec.estimator),
        spec.param_grid,
        cv=splitter,
        scoring="neg_root_mean_squared_error",
        n_jobs=1,
        refit=True,
    )
    search.fit(x_train, y_train)
    return search.best_estimator_, search.best_params_


def regime_for_date(date: pd.Timestamp) -> str:
    if date < pd.Timestamp("2020-01-01"):
        return "pre_covid"
    if date < pd.Timestamp("2022-01-01"):
        return "covid"
    if date < pd.Timestamp("2024-01-01"):
        return "high_inflation"
    return "disinflation"


def run_forecasts(
    data: pd.DataFrame,
    panel_x: pd.DataFrame,
    ar_x: pd.DataFrame,
    factor_ar_x: pd.DataFrame,
    horizons: list[int],
    models: list[str],
    oos_start: pd.Timestamp,
    min_train: int,
    seed: int,
    smoke: bool,
    information_lag: int,
    window: str,
    rolling_months: int,
    cv_splits: int,
    rf_estimators: int,
    max_origins: int | None,
) -> tuple[pd.DataFrame, list[dict[str, Any]]]:
    rows: list[dict[str, Any]] = []
    tuning_log: list[dict[str, Any]] = []
    parameter_cache: dict[tuple[str, int, int], dict[str, Any]] = {}

    if smoke:
        horizons = [h for h in horizons if h in (1, 12)] or [1]

    for horizon in horizons:
        target_col = f"target_h{horizon}"
        possible = data.index[(data["Date"] >= oos_start) & data[target_col].notna()]
        if smoke:
            possible = possible[-6:]
        elif max_origins is not None:
            possible = possible[-max_origins:]

        for origin_idx in possible:
            origin_date = data.at[origin_idx, "Date"]
            if origin_date.month == 1 or origin_idx == possible[-1]:
                print(
                    f"h={horizon}: forecasting {origin_date:%Y-%m} "
                    f"({len(rows):,} rows accumulated)",
                    flush=True,
                )
            latest_train_idx = origin_idx - horizon
            if latest_train_idx < 0:
                continue

            train_mask = (
                (data.index <= latest_train_idx)
                & data[target_col].notna()
                & ar_x.notna().any(axis=1)
            )
            train_idx = data.index[train_mask]
            if window == "rolling":
                first_rolling_idx = max(0, latest_train_idx - rolling_months + 1)
                train_idx = train_idx[train_idx >= first_rolling_idx]
            if len(train_idx) < min_train:
                continue

            y_train = data.loc[train_idx, target_col]
            actual = float(data.at[origin_idx, target_col])
            target_date = origin_date + pd.DateOffset(months=horizon)
            latest_train_origin_date = data.at[latest_train_idx, "Date"]

            for model_name in models:
                if model_name == "historical_mean":
                    prediction = float(y_train.mean())
                    params: dict[str, Any] = {}
                elif model_name == "naive":
                    naive_idx = origin_idx - information_lag
                    if naive_idx < 0:
                        continue
                    prediction = float(data.at[naive_idx, "infl_yoy"])
                    params: dict[str, Any] = {}
                else:
                    if model_name == "ar":
                        x_all = ar_x
                    elif model_name == "factor_ar":
                        x_all = factor_ar_x
                    else:
                        x_all = panel_x
                    x_train = x_all.loc[train_idx]
                    x_test = x_all.loc[[origin_idx]]
                    specs = make_specs(
                        seed,
                        x_train.shape[1],
                        len(x_train),
                        smoke,
                        factor_panel_count=panel_x.shape[1],
                        factor_ar_term_count=ar_x.shape[1],
                        rf_estimators=rf_estimators,
                    )
                    spec = specs[model_name]
                    cache_key = (model_name, horizon, origin_date.year)

                    # Tune once at the first available origin of each calendar
                    # year and reuse that choice.  This limits repeated searching
                    # over the evaluation sample while every model is still
                    # re-estimated at each forecast origin.
                    if spec.param_grid and cache_key in parameter_cache:
                        params = parameter_cache[cache_key]
                        estimator = clone(spec.estimator).set_params(**params)
                        estimator.fit(x_train, y_train)
                    else:
                        estimator, params = tune_if_needed(
                            spec, x_train, y_train, horizon, cv_splits
                        )
                        if spec.param_grid:
                            parameter_cache[cache_key] = params
                            tuning_log.append(
                                {
                                    "model": model_name,
                                    "horizon": horizon,
                                    "origin_date": origin_date.strftime("%Y-%m-%d"),
                                    "n_train": len(train_idx),
                                    "best_params": params,
                                }
                            )
                    prediction = float(estimator.predict(x_test)[0])

                rows.append(
                    {
                        "origin_date": origin_date,
                        "target_date": target_date,
                        "latest_train_origin_date": latest_train_origin_date,
                        "latest_train_target_date": origin_date,
                        "horizon": horizon,
                        "model": model_name,
                        "actual": actual,
                        "forecast": prediction,
                        "error": actual - prediction,
                        "regime": regime_for_date(target_date),
                        "n_train": len(train_idx),
                        "params": json.dumps(params, sort_keys=True),
                    }
                )

    predictions = pd.DataFrame(rows)
    if predictions.empty:
        raise RuntimeError("No forecasts were produced; check dates and min_train.")
    return predictions, tuning_log


def summarise_metrics(predictions: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    def summarise(group: pd.DataFrame) -> pd.Series:
        return pd.Series(
            {
                "n": len(group),
                "rmse": math.sqrt(mean_squared_error(group["actual"], group["forecast"])),
                "mae": mean_absolute_error(group["actual"], group["forecast"]),
            }
        )

    overall = (
        predictions.groupby(["horizon", "model"], sort=True)
        .apply(summarise, include_groups=False)
        .reset_index()
    )
    by_regime = (
        predictions.groupby(["horizon", "regime", "model"], sort=True)
        .apply(summarise, include_groups=False)
        .reset_index()
    )

    for frame, keys in (
        (overall, ["horizon"]),
        (by_regime, ["horizon", "regime"]),
    ):
        benchmark = frame.loc[frame["model"] == "ar", keys + ["rmse", "mae"]].rename(
            columns={"rmse": "ar_rmse", "mae": "ar_mae"}
        )
        merged = frame.merge(benchmark, on=keys, how="left")
        frame["rmse_relative_to_ar"] = merged["rmse"] / merged["ar_rmse"]
        frame["mae_relative_to_ar"] = merged["mae"] / merged["ar_mae"]

    return overall, by_regime


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    horizons = sorted(set(args.horizons))
    data, predictor_cols = load_data(args.data_dir, horizons)
    if args.variable_set == "core":
        missing_core = sorted(set(CORE_VARIABLES).difference(predictor_cols))
        if missing_core:
            raise KeyError(f"Core variables not found in balanced UK-MD: {missing_core}")
        predictor_cols = list(CORE_VARIABLES)
    panel_x, ar_x = build_feature_frames(
        data,
        predictor_cols,
        args.panel_lags,
        args.ar_lags,
        args.information_lag,
    )
    factor_ar_x = pd.concat([panel_x, ar_x.add_prefix("AR_DIRECT__")], axis=1)
    predictions, tuning_log = run_forecasts(
        data=data,
        panel_x=panel_x,
        ar_x=ar_x,
        factor_ar_x=factor_ar_x,
        horizons=horizons,
        models=args.models,
        oos_start=pd.Timestamp(args.oos_start),
        min_train=args.min_train,
        seed=args.seed,
        smoke=args.smoke,
        information_lag=args.information_lag,
        window=args.window,
        rolling_months=args.rolling_months,
        cv_splits=args.cv_splits,
        rf_estimators=args.rf_estimators,
        max_origins=args.max_origins,
    )
    overall, by_regime = summarise_metrics(predictions)

    predictions.to_csv(args.output_dir / "predictions.csv", index=False)
    overall.to_csv(args.output_dir / "metrics_overall.csv", index=False)
    by_regime.to_csv(args.output_dir / "metrics_by_regime.csv", index=False)
    (args.output_dir / "tuning_log.json").write_text(
        json.dumps(tuning_log, indent=2), encoding="utf-8"
    )

    metadata = {
        "data_start": data["Date"].min().strftime("%Y-%m-%d"),
        "data_end": data["Date"].max().strftime("%Y-%m-%d"),
        "n_rows": len(data),
        "n_predictors": len(predictor_cols),
        "panel_lags": args.panel_lags,
        "ar_lags": args.ar_lags,
        "information_lag": args.information_lag,
        "variable_set": args.variable_set,
        "window": args.window,
        "rolling_months": args.rolling_months,
        "cv_splits": args.cv_splits,
        "rf_estimators": args.rf_estimators,
        "seed": args.seed,
        "max_origins": args.max_origins,
        "horizons": horizons,
        "models": args.models,
        "oos_start": args.oos_start,
        "min_train": args.min_train,
        "smoke": args.smoke,
    }
    (args.output_dir / "run_metadata.json").write_text(
        json.dumps(metadata, indent=2), encoding="utf-8"
    )

    print(overall.round(3).to_string(index=False))
    print(f"\nSaved results to: {args.output_dir.resolve()}")


if __name__ == "__main__":
    main()
