# Data provenance and use

The package contains the March 2026 vintage of the United Kingdom
Macroeconomic Database (UK-MD) used in the dissertation:

- `UKMD_March_2026/raw_uk_md.csv`: provider raw monthly series, including the
  headline CPI index used to construct the forecast target.
- `UKMD_March_2026/balanced_uk_md.csv`: provider balanced monthly panel used as
  the common predictor information set.
- `UKMD_March_2026/tr_uk_md.csv`: provider transformation-code file.

The analysis begins in January 1998 because that is the start of the balanced
111-variable panel. Forecast evaluation begins in January 2008. Provider
transformation codes are applied inside the Python pipeline. Missing-value
imputation, standardisation, PCA and hyperparameter selection are estimated
using training data only at each forecast origin.

The data files are included for dissertation assessment and replication. Check
the UK-MD provider's current licence before redistributing them publicly.
