@echo off
cd /d "%~dp0"
echo WARNING: the full run refits all models and robustness checks and may take one to three days.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File ".\run_all.ps1" -Mode full
pause
